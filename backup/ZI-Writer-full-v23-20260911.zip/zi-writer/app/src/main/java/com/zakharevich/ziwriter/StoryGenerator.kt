
package com.zakharevich.ziwriter

import kotlin.random.Random

object StoryGenerator {

    data class GenerationConfig(
        val originalText: String,
        val pages: Int,
        val genre: String,
        val style: String,
        val fixGrammar: Boolean = true,
        val customHeroes: List<String> = emptyList(),
        val customPlace: String = "",
        val bookTitle: String = "",
        val authorName: String = "",
        val learnedTemplates: List<String> = emptyList(),
        val useLearned: Boolean = true
    )

    data class GeneratedStory(
        val title: String,
        val fullText: String,
        val chars: Int,
        val pages: Int,
        val heroes: List<String>,
        val keywords: List<String>,
        val correctedOriginal: String
    )

    private const val CHARS_PER_PAGE = 1800

    private fun containsCJK(text: String): Boolean {
        for (c in text) {
            val code = c.code
            if (code in 0x3040..0x309F) return true
            if (code in 0x30A0..0x30FF) return true
            if (code in 0x4E00..0x9FFF) return true
            if (code in 0xAC00..0xD7AF) return true
        }
        return false
    }

    private fun isValidLearnedTemplate(t: String): Boolean {
        if (t.length < 30 || t.length > 400) return false
        if (containsCJK(t)) return false
        val lower = t.lowercase()
        val blacklist = listOf("посёлок", "поселок", "уезд", "префектура", "муниципалитет", "населённый пункт", "камимасики", "кумамото", "касима-мати", "嘉島町", "административный центр", "сельское поселение")
        for (b in blacklist) if (lower.contains(b)) return false
        if (lower.contains("википедия")) return false
        return true
    }

    fun detectGenreStatic(text: String): String {
        val lower = text.lowercase()
        return when {
            lower.contains("выстрел") || lower.contains("оружие") || lower.contains("спецоперация") -> "Боевик"
            lower.contains("улика") || lower.contains("следователь") || lower.contains("детектив") -> "Детектив"
            lower.contains("любовь") || lower.contains("сердце") || lower.contains("поцелуй") -> "Роман"
            lower.contains("космос") || lower.contains("корабль") || lower.contains("галактика") -> "Фантастика"
            lower.contains("приключен") || lower.contains("экспедиция") -> "Приключения"
            lower.contains("призрак") || lower.contains("хоррор") -> "Хоррор"
            lower.contains("юмор") -> "Юмор"
            lower.contains("философ") || lower.contains("душа") || lower.contains("сознание") -> "Философская проза"
            else -> "general"
        }
    }

    private fun extractTrigrams(text: String): Set<String> {
        val words = text.lowercase().replace(Regex("[^а-яёa-z ]"), " ").split(Regex("\\s+")).filter { it.length > 2 }
        if (words.size < 3) return emptySet()
        val set = mutableSetOf<String>()
        for (i in 0..words.size-3) set.add("${words[i]} ${words[i+1]} ${words[i+2]}")
        return set
    }

    private fun jaccard(a: String, b: String): Double {
        val sa = a.lowercase().replace(Regex("[^а-яёa-z ]"), " ").split(Regex("\\s+")).filter { it.length > 3 }.toSet()
        val sb = b.lowercase().replace(Regex("[^а-яёa-z ]"), " ").split(Regex("\\s+")).filter { it.length > 3 }.toSet()
        if (sa.isEmpty() || sb.isEmpty()) return 0.0
        val inter = sa.intersect(sb).size
        val union = sa.union(sb).size
        return inter.toDouble() / union
    }

    private fun smoothText(text: String): String {
        val sentences = text.split(Regex("(?<=[.!?])\\s+"))
        val seen = mutableSetOf<String>()
        val res = mutableListOf<String>()
        for (s in sentences) {
            val t = s.trim()
            if (t.length < 15) { res.add(s); continue }
            val low = t.lowercase()
            if (low in seen) continue
            if (res.takeLast(4).any { jaccard(t, it) > 0.72 }) continue
            res.add(s)
            seen.add(low)
            if (seen.size > 300) {
                seen.removeAll(seen.take(100).toSet())
            }
        }
        return res.joinToString(" ")
    }

    private val bannedOverused = listOf(
        "лишь декорация, главное внутри",
        "лишь декорация, главное происходит внутри",
        "холодные простыни",
        "мышечная память",
        "точка А и точка Б",
        "винт в системе",
        "право на улыбку"
    )

    fun generate(config: GenerationConfig): GeneratedStory {
        val rawOriginal = config.originalText.trim()
        val original = if (config.fixGrammar) GrammarCorrector.correct(rawOriginal) else rawOriginal
        val targetChars = config.pages * CHARS_PER_PAGE
        val extractedHeroes = extractHeroesV4(original)
        val heroes = if (config.customHeroes.isNotEmpty()) config.customHeroes else extractedHeroes
        val keywords = extractKeywords(original)
        val mainPlace = if (config.customPlace.isNotEmpty()) config.customPlace else randomPlaceFull(config.genre)
        val placeNoun = randomPlaceNoun(config.genre)
        val title = if (config.bookTitle.isNotBlank()) config.bookTitle.trim() else generateTitle(original, keywords, config.genre)
        val isPhil = detectPhilosophical(original, keywords)

        val sb = StringBuilder()
        sb.append(original)
        if (!original.endsWith("\n")) sb.append("\n\n")
        sb.append(generateBridge(heroes, mainPlace, isPhil))
        sb.append("\n\n")

        var curPage = 1
        var outlineIdx = 0
        val outline = createOutline(config.pages, config.genre, heroes, keywords, isPhil)
        val used = mutableMapOf<String, MutableSet<Int>>()
        val usedTrigrams = mutableSetOf<String>()
        val recentParas = mutableListOf<String>()
        val recentPlaces = mutableListOf(mainPlace)
        val usedBanned = mutableSetOf<String>()
        val usedStarters = mutableMapOf<String, Int>()

        while (sb.length < targetChars) {
            if (sb.length > original.length + 800 && outlineIdx % 4 == 0 && config.pages > 3) {
                curPage++
                if (curPage <= config.pages) sb.append("\n\n— — — Страница $curPage — — —\n\n")
            }
            if (outlineIdx % 3 == 0 && config.pages >= 2 && outlineIdx < outline.size) {
                val ch = outline[outlineIdx]
                if (ch.startsWith("Глава") || ch.startsWith("Пролог") || ch.startsWith("Эпилог")) {
                    sb.append("\n${ch.uppercase()}\n\n")
                }
            }

            val curPlace = if (config.customPlace.isNotEmpty()) config.customPlace else {
                if (Random.nextFloat() < 0.65) {
                    var np: String
                    var att = 0
                    do {
                        np = randomPlaceFull(config.genre)
                        att++
                    } while (np in recentPlaces.takeLast(3) && att < 6)
                    recentPlaces.add(np)
                    if (recentPlaces.size > 6) recentPlaces.removeAt(0)
                    np
                } else mainPlace
            }

            var para: String
            var att = 0
            do {
                para = if (isPhil) {
                    generatePhilosophicalParagraph(config.style, used, heroes, curPlace, config.learnedTemplates, config.useLearned, recentParas, usedBanned, usedStarters)
                } else {
                    generateNarrativeParagraph(config.genre, config.style, heroes, keywords, curPlace, placeNoun, used, config.learnedTemplates, config.useLearned, recentParas, usedBanned, usedStarters)
                }
                att++
                val sim = recentParas.takeLast(4).any { jaccard(para, it) > 0.58 }
                val trig = extractTrigrams(para).count { it in usedTrigrams } >= 3
                if (!sim && !trig) break
            } while (att < 8)

            for (b in bannedOverused) {
                if (para.contains(b, ignoreCase = true)) {
                    if (b.lowercase() in usedBanned) {
                        para = para.replace(Regex("(?i)"+Regex.escape(b)), "").replace(Regex("\\s+"), " ").trim()
                    } else {
                        usedBanned.add(b.lowercase())
                    }
                }
            }

            usedTrigrams.addAll(extractTrigrams(para))
            if (usedTrigrams.size > 600) {
                val keep = usedTrigrams.take(350).toSet()
                usedTrigrams.clear()
                usedTrigrams.addAll(keep)
            }

            if (recentParas.isNotEmpty() && !isPhil && Random.nextFloat() < 0.45) {
                val connectors = listOf("Потом ", "Через час ", "Вдруг ", "Но ", "Однако ", "Тем временем ", "К вечеру ", "На рассвете ", "Спустя минуту ", "Между тем ", "Чуть позже ", "В тот же миг ")
                if (connectors.none { para.startsWith(it) }) {
                    para = connectors.random() + para.replaceFirstChar { it.lowercase() }
                }
            }

            if (isPhil && recentParas.isNotEmpty() && Random.nextFloat() < 0.4) {
                val philConnectors = listOf("Иногда ", "Знаешь, ", "Вспомни, ", "Представь, ", "При этом ", "И еще ", "А еще ", "Между тем ", "К тому же ")
                if (para.startsWith("Ты ") && (usedStarters["Ты"] ?: 0) > 3) {
                    para = philConnectors.random() + para.replaceFirstChar { it.lowercase() }.removePrefix("ты ").replaceFirstChar { it.uppercase() }
                }
            }

            val starter = para.split(" ").firstOrNull()?.replace(Regex("[^А-Яа-яЁёA-Za-z]"), "") ?: ""
            if (starter.isNotEmpty()) {
                usedStarters[starter] = (usedStarters[starter] ?: 0) + 1
            }

            recentParas.add(para)
            if (recentParas.size > 12) recentParas.removeAt(0)

            sb.append(para)
            sb.append("\n\n")
            outlineIdx++
            if (outlineIdx > config.pages * 35) break
        }

        sb.append(generateEnding(config.genre, heroes, keywords, mainPlace, isPhil, config.authorName))
        var finalText = sb.toString().take(targetChars + 1000)
        finalText = smoothText(finalText)
        finalText = finalText.replace(Regex("\\s+"), " ").replace(" .", ".").replace(" ,", ",").replace("  ", " ")

        val actualPages = (finalText.length + CHARS_PER_PAGE - 1) / CHARS_PER_PAGE
        return GeneratedStory(title, finalText, finalText.length, actualPages, if (heroes.isEmpty()) listOf("он") else heroes, keywords, original)
    }

    private fun detectPhilosophical(text: String, keywords: List<String>): Boolean {
        val lower = text.lowercase()
        val markers = listOf("жизнь", "душа", "сознание", "внутренний голос", "голос", "счастье", "любовь", "мироздание", "человек", "сам с собой", "одиночеств", "мысль", "чувств", "детстве", "учителя", "мораль", "судьба", "выбор", "страх", "свобода", "простын")
        val count = markers.count { lower.contains(it) }
        val hasFirstPerson = lower.contains(" я ") || lower.contains(" мне ") || lower.contains(" меня ") || lower.startsWith("я ")
        return count >= 3 || (count >= 2 && hasFirstPerson) || keywords.contains("жизнь") || keywords.contains("голос")
    }

    private val commonFirstNames = setOf(
        "марина", "алексей", "алекс", "игорь", "анна", "елена", "дмитрий", "сергей", "ольга", "татьяна",
        "иван", "петр", "мария", "наталья", "андрей", "михаил", "юлия", "светлана", "виктор", "николай",
        "владимир", "екатерина", "александр", "александра", "ксения", "дарья", "артем", "артём", "максим",
        "кирилл", "павел", "роман", "денис", "евгений", "константин", "валентина", "галина", "лариса", "оксана", "ирина",
        "наташа", "саша", "леша", "дима", "лена", "катя", "маша", "даша", "женя", "костя", "вова", "паша"
    )

    private val extensiveStopLower = setOf(
        "его", "её", "ее", "еще", "ещё", "может", "твоя", "твои", "твоё", "твой", "твоей", "твоем", "твоих", "твоим",
        "она", "он", "оно", "они", "мы", "вы", "ты", "это", "тот", "та", "те", "так", "вот", "там", "тут", "как", "что", "кто", "где", "когда", "почему", "откуда", "зачем",
        "вечер", "утро", "день", "ночь", "город", "дом", "мир", "жизнь", "время", "человек", "люди", "все", "всё", "просто", "странным", "образом", "точка", "улица", "школу", "институт", "работу", "женщин", "старикам", "учителя",
        "весь", "вся", "всю", "всех", "всем", "сам", "сама", "сами", "само", "самой", "самого", "меня", "мне", "мной", "тебя", "тебе", "тобой", "себя", "себе", "собой", "нас", "нам", "нами", "вас", "вам",
        "был", "была", "были", "будет", "будут", "есть", "быть", "можно", "нужно", "надо", "очень", "даже", "уже", "только", "однако", "потому", "поэтому", "чтобы", "если", "когда", "тогда", "сейчас", "потом",
        "мышечная", "последний", "первый", "второй", "третий", "большой", "маленький", "хороший", "плохой", "новый", "старый", "точный", "четко", "чётко", "холодный", "теплый", "горячий",
        "обычный", "необычный", "случайный", "многолюдный", "пустой", "полный", "одинокий", "желанный", "упругий", "нежный", "влажный", "неистовый", "сознательный", "счастливый", "безрассудный", "человеческий",
        "первая", "первое", "вторая", "второе", "третья", "третье", "последняя", "последнее", "обычная", "обычное", "случайная", "случайное",
        "было", "будет", "стало", "пошел", "пошёл", "пришел", "пришёл", "ушел", "ушёл", "сказал", "говорит", "думал", "понял", "попал", "понимал", "подвела", "подвёл",
        "книга", "история", "рассказ", "роман", "глава", "страница", "лист", "текст", "слово", "фраза"
    )

    private val adjectiveEndings = listOf("ая", "яя", "ое", "ее", "ые", "ие", "ый", "ий", "ой", "ых", "их", "ую", "юю", "ем", "им", "ым", "ом", "его", "ого")

    private fun isLikelyAdjective(word: String): Boolean {
        val lower = word.lowercase()
        if (lower.length < 5) return false
        if (lower in commonFirstNames) return false
        return adjectiveEndings.any { lower.endsWith(it) } && lower !in setOf("мария", "софия", "юлия", "анастасия", "дарья", "ксения")
    }

    private fun extractHeroesV4(text: String): List<String> {
        val sentences = text.split(Regex("[.!?]+")).map { it.trim() }.filter { it.isNotEmpty() }
        val candidates = mutableListOf<String>()
        val firstWordsThatAreNames = mutableListOf<String>()
        val nameFreq = mutableMapOf<String, Int>()
        for (sentence in sentences) {
            val words = sentence.split(Regex("\\s+")).map { it.replace(Regex("[^А-Яа-яЁёA-Za-z-]"), "") }.filter { it.isNotEmpty() }
            if (words.isEmpty()) continue
            val first = words[0]
            if (first.matches(Regex("[А-ЯЁ][а-яё]{2,}")) && first.lowercase() in commonFirstNames) {
                firstWordsThatAreNames.add(first)
                nameFreq[first.lowercase()] = (nameFreq[first.lowercase()] ?: 0) + 1
            }
            for (i in 1 until words.size) {
                val w = words[i]
                if (!w.matches(Regex("[А-ЯЁ][а-яё]{2,}"))) continue
                if (w.length < 3 || w.length > 15) continue
                val lower = w.lowercase()
                if (lower in extensiveStopLower) continue
                if (isLikelyAdjective(w)) continue
                val lowerCount = Regex("\\b${Regex.escape(lower)}\\b", RegexOption.IGNORE_CASE).findAll(text).count()
                val upperCount = Regex("\\b${Regex.escape(w)}\\b").findAll(text).count()
                if (lowerCount > upperCount * 2) continue
                candidates.add(w)
                nameFreq[lower] = (nameFreq[lower] ?: 0) + 1
            }
        }
        val all = (candidates + firstWordsThatAreNames).distinct()
        val sorted = all.sortedWith(compareByDescending<String> { nameFreq[it.lowercase()] ?: 0 }.thenByDescending { it.lowercase() in commonFirstNames })
        return sorted.filter { it.lowercase() in commonFirstNames || candidates.count { c -> c == it } >= 1 }.take(3)
    }

    private fun extractKeywords(text: String): List<String> {
        val words = text.lowercase().replace(Regex("[^а-яёa-z ]"), " ").split(Regex("\\s+")).filter { it.length > 3 }
        val stopWords = setOf(
            "который", "которая", "которые", "которое", "которых", "потому", "однако", "только", "очень", "сейчас", "тогда", "чтобы", "когда", "такой", "такая", "такое", "такие",
            "было", "была", "были", "будет", "будут", "можно", "нужно", "надо", "через", "против", "между", "самый", "самом", "самой",
            "этот", "эта", "это", "эти", "этого", "этой", "этом", "тот", "та", "то", "те", "того", "той", "том",
            "весь", "вся", "всё", "все", "всех", "всем", "всеми", "всю", "сам", "сама", "сами", "его", "её", "ее", "еще", "ещё", "может", "твоя", "твои",
            "меня", "мне", "мной", "тебя", "тебе", "тобой", "себя", "себе", "собой", "нас", "нам", "нами", "вас", "вам",
            "мышечная", "память", "подвела"
        )
        val important = setOf("жизнь", "голос", "любовь", "счастье", "душа", "сердце", "мироздание", "сознание", "детство", "школа", "учитель", "мораль", "судьба", "выбор", "страх", "свобода", "одиночество", "тело", "дыхание", "желание", "выстрел", "цель", "тайна", "правда", "время")
        val filtered = words.filter { it !in stopWords || it in important }
        val freq = filtered.groupingBy { it }.eachCount()
        return freq.entries.sortedByDescending { it.value }.map { it.key }.take(12)
    }

    private fun randomPlaceFull(genre: String): String {
        val places = when (genre) {
            "Фантастика" -> listOf("на краю Галактики", "на станции Орион-9", "в заброшенном космопорте", "у квантового разлома", "в городе из стекла и света", "на орбите Марса", "в лаборатории времени", "на корабле Аврора", "в куполе на Луне", "у черной дыры", "в нейросети", "в колонии на Титане", "в отсеке с криокапсулами", "на мостике звездолёта")
            "Детектив", "Боевик" -> listOf("в старом районе города", "на заброшенном складе", "в ночном кафе", "в архиве полиции", "на крыше", "в подвале", "у окна", "на перекрестке", "в переулке", "на вокзале", "в порту", "в гараже", "в кабинете следователя", "в отделе улик", "на месте преступления", "в дежурной части", "у реки за городом")
            "Роман" -> listOf("на берегу моря", "в маленьком городке у реки", "в старом парке", "в уютном кафе", "на многолюдной улице", "в пустой квартире", "у камина", "на мосту", "в саду с розами", "на набережной", "в библиотеке", "в поезде", "в осеннем сквере", "на кухне с видом на двор")
            "Приключения" -> listOf("в джунглях Амазонки", "на затерянном острове", "на горном перевале", "в пустыне Сахара", "в древнем храме", "в пещере с кристаллами", "на пиратском корабле", "в лабиринте", "на вершине Эвереста", "в долине гейзеров", "в ущелье ветров", "на краю карты")
            "Хоррор" -> listOf("в заброшенной больнице", "в старом доме на холме", "в темном лесу", "в подвале с шепотом", "в туманной деревне", "в склепе", "в доме с зеркалами", "на кладбище", "в лесу без птиц", "в квартире 13", "в коридоре без ламп", "у заколоченного окна")
            "Юмор" -> listOf("в офисе с кофемашиной", "в супермаркете в час пик", "в маршрутке 42", "в чате домового ТСЖ", "в квартире с котом", "на корпоративе", "в очереди в поликлинике", "в лифте с соседом", "на даче у тещи", "в коворкинге", "у кулера с водой")
            "Философская проза", "Драма" -> listOf("внутри себя", "на перекрестке дорог", "на берегу моря", "в тихом городе", "в пустой квартире", "у окна", "на краю мира", "в точке А", "в точке Б", "между прошлым и будущим", "внутри тишины", "на многолюдной улице", "в комнате с приглушённым светом", "наедине с мыслями")
            else -> listOf("на берегу моря", "в тихом городе", "на перекрестке дорог", "внутри себя", "на многолюдной улице", "в пустой квартире", "у окна", "на краю мира", "в старом парке", "в кафе", "в вагоне метро", "на остановке под дождём")
        }
        return places.random()
    }

    private fun randomPlaceNoun(genre: String): String {
        val places = when (genre) {
            "Детектив", "Боевик" -> listOf("заброшенный склад", "старый район", "ночное кафе", "архив полиции", "крыша", "подвал", "перекресток", "кабинет следователя", "переулок", "вокзал", "порт", "гараж", "отдел улик", "место преступления")
            "Роман" -> listOf("берег моря", "маленький городок", "старый парк", "уютное кафе", "многолюдная улица", "пустая квартира", "камин", "мост", "сад", "набережная", "библиотека")
            "Фантастика" -> listOf("космопорт", "станция Орион", "квантовый разлом", "город из стекла", "корабль", "лаборатория", "купол", "колония")
            else -> listOf("тихий город", "перекресток дорог", "пустая квартира", "берег моря", "старый парк", "окно", "кафе", "улица")
        }
        return places.random()
    }

    private fun generateTitle(original: String, keywords: List<String>, genre: String): String {
        val key = keywords.firstOrNull()?.replaceFirstChar { it.uppercase() } ?: "Тишина"
        val key2 = keywords.getOrElse(1) { "судьба" }
        val key3 = keywords.getOrElse(2) { "дорога" }
        val titles = when (genre) {
            "Боевик" -> listOf("Последний выстрел", "Точка невозврата", "Мышечная память", "Попадание в цель", "На пределе", "Один шанс", "Без права на промах", "Холодный расчет", "Линия огня", "Код $key", "Операция $key2", "Последний рубеж")
            "Философская проза" -> listOf("Внутренний голос", "Точка А и точка Б", "Там, где кончается страх", "Письмо к себе", "Право на улыбку", "Быть собой", "Тишина простыней", "Голос внутри", "Право идти прямо", "Когда $key молчит")
            "Детектив" -> listOf("Дело № $key", "Тени $key2", "Улика из $key", "Ночной разговор", "Последний свидетель", "Тайна ${placeHolder()}", "Код $key3", "Архив $key", "След $key2")
            "Фантастика" -> listOf("Станция $key", "Квантовый $key2", "Галактика $key", "Код Орион", "Время $key3", "Сигнал $key", "Последний корабль", "Город из $key2")
            "Роман" -> listOf("Когда $key молчит", "$key и $key2", "Письмо про $key2", "Берег $key", "Мост $key2", "Осень $key", "Право на $key2", "Тихий $key3")
            "Приключения" -> listOf("Остров $key", "Карта $key2", "Сокровище $key", "Перевал $key2", "Храм $key", "Экспедиция $key3")
            "Хоррор" -> listOf("Дом $key", "Шепот $key2", "Тени $key", "Квартира 13", "Лес без $key2", "Зеркала $key")
            "Юмор" -> listOf("Офис $key", "Кот $key2", "Маршрутка $key", "Корпоратив $key3", "Чат ТСЖ", "Супермаркет $key")
            else -> listOf("Когда $key молчит", "$key и $key2", "Тени $key2", "Право на $key2", "Дорога без указателей", "Эхо $key", "История $key", "Код $key3")
        }
        return titles.random()
    }

    private fun placeHolder(): String = listOf("прошлого", "будущего", "тишины", "ночи", "города", "памяти").random()

    private fun createOutline(pages: Int, genre: String, heroes: List<String>, keywords: List<String>, isPhilosophical: Boolean): List<String> {
        return if (isPhilosophical) {
            listOf(
                "Пролог: Голос внутри",
                "Глава 1: Откуда он взялся",
                "Детство до школы",
                "Глава 2: Точка А — точка Б",
                "Встреча на улице",
                "Глава 3: Право на улыбку",
                "Поворот: Одна секунда",
                "Глава 4: Учителя и мораль",
                "Глава 5: Быть собой",
                "Интерлюдия: Тишина простыней",
                "Глава 6: Право идти прямо",
                "Эпилог: Жить без него",
                "Послесловие"
            )
        } else {
            when (genre) {
                "Боевик" -> listOf("Пролог: Последний выстрел", "Глава 1: Мышечная память", "Затишье", "Глава 2: Точка невозврата", "Разбор", "Глава 3: Попадание в цель", "Глава 4: Тишина после", "Глава 5: Новая цель", "Эпилог: Дорога вперед")
                "Детектив" -> listOf("Пролог: Звонок в полночь", "Глава 1: Место преступления", "Глава 2: Первый свидетель", "Улика", "Глава 3: Ложный след", "Глава 4: Архив", "Глава 5: Правда", "Развязка", "Эпилог: Дело закрыто")
                "Роман" -> listOf("Пролог: Встреча", "Глава 1: Письмо", "Глава 2: Вечер", "Разговор", "Глава 3: Расстояние", "Глава 4: Возвращение", "Глава 5: Выбор", "Эпилог: Вместе")
                "Фантастика" -> listOf("Пролог: Сигнал", "Глава 1: Станция Орион", "Глава 2: Квантовый разлом", "Глава 3: Город из стекла", "Глава 4: Время", "Глава 5: Выбор", "Эпилог: Новая Галактика")
                "Приключения" -> listOf("Пролог: Карта", "Глава 1: Сборы", "Глава 2: Перевал", "Глава 3: Храм", "Глава 4: Ловушка", "Глава 5: Сокровище", "Эпилог: Возвращение")
                "Хоррор" -> listOf("Пролог: Шепот", "Глава 1: Дом на холме", "Глава 2: Зеркала", "Глава 3: Подвал", "Глава 4: Правда", "Глава 5: Побег", "Эпилог: Тишина")
                "Юмор" -> listOf("Пролог: Понедельник", "Глава 1: Офис", "Глава 2: Кофемашина", "Глава 3: Корпоратив", "Глава 4: Кот", "Глава 5: Чат ТСЖ", "Эпилог: Пятница")
                else -> listOf("Пролог", "Глава 1: Первая тайна", "Встреча", "Глава 2: Тени прошлого", "Поворот", "Глава 3: Испытание", "Раскрытие", "Кульминация", "Эпилог")
            }
        }
    }

    private fun generateBridge(heroes: List<String>, placeFull: String, isPhilosophical: Boolean): String {
        return if (isPhilosophical) {
            "С этих строк начинается попытка разобраться. Ты уже сказал главное. Дальше — только честность. Без учителей, без морали, которую тебе навязали. Только ты и то, что внутри. $placeFull — лишь декорация, главное происходит внутри."
        } else {
            val hero = heroes.firstOrNull() ?: "он"
            "С этих строк началась история, которая вскоре вышла за пределы привычного. $hero еще не знал, что каждое слово, сказанное в тот момент $placeFull, станет частью чего-то большего. Иногда одна секунда меняет всё."
        }
    }

    private fun generatePhilosophicalParagraph(style: String, used: MutableMap<String, MutableSet<Int>>, heroes: List<String>, placeFull: String, learned: List<String> = emptyList(), useLearned: Boolean = true, recentParagraphs: List<String> = emptyList(), usedBanned: Set<String> = emptySet(), usedStarters: Map<String, Int> = emptyMap()): String {
        val filteredLearned = learned.filter { isValidLearnedTemplate(it) }
        if (useLearned && filteredLearned.isNotEmpty() && Random.nextFloat() < 0.12f) {
            val key = "phil_learned"
            val usedSet = used.getOrPut(key) { mutableSetOf() }
            if (usedSet.size >= filteredLearned.size) usedSet.clear()
            var attempts = 0
            var idx: Int
            var learnedText: String
            do {
                val available = filteredLearned.indices.filter { it !in usedSet }
                idx = if (available.isNotEmpty()) available.random() else Random.nextInt(filteredLearned.size)
                learnedText = filteredLearned[idx]
                attempts++
            } while (attempts < 5 && recentParagraphs.any { jaccard(learnedText, it) > 0.5 })
            usedSet.add(idx)
            return if (style == "Лаконичный") {
                learnedText.split(". ").take(2).joinToString(". ") + "."
            } else if (style == "Поэтический") {
                learnedText + " Воздух густой, как чернила."
            } else {
                learnedText
            }
        }
        val key = "phil"
        val paragraphs = listOf(
            "Этот внутренний голос — откуда он вообще взялся? Ты помнишь себя до школы? Вот ты во дворе, тебе пять лет. Ты говоришь то, что думаешь. Хочешь — дружишь, не хочешь — не дружишь. Плачешь, когда больно, смеешься, когда смешно. Никому не надо объяснять, почему ты так чувствуешь. А потом приходят они. Учителя, взрослые, правила. И ты впервые уступаешь. Не потому что согласен, а потому что боишься.",
            "Иногда кажется, что всю жизнь делал всё правильно. Школа, институт, работа, семья, дом, дерево. Уступал место, пропускал вперед, не нарушал закон мироздания. И что в итоге? Тишина. И этот голос, который теперь звучит твоим же тембром. Он говорит, что ты недостаточно хорош.",
            "Вспомни ту встречу. Многолюдная улица, ты идешь, уткнувшись в дела. И вдруг — глаза. Она тоже спешит, тоже винт в системе. Но в одну и ту же секунду вы оба поднимаете взгляд. Что это, если не шанс? И в голове мелькает простая мысль — улыбнуться. Просто дать человеку секунду тепла.",
            "Кто он такой, этот голос? Может, это и есть то, что отличает нас от других? Сомнение, рефлексия. Звучит благородно. Но на деле — это просто страх. Страх быть отвергнутым, показаться глупым, нарушить правила, которые придумали люди, сами ничего не достигшие.",
            "Представь, что было бы, если бы ты не прошел мимо. Если бы остановил взгляд и улыбнулся. Мир не рухнул бы. Просто один человек стал бы на секунду счастливее. Может, на жизнь. Ты не знаешь, пока слушаешь его. Его задача — не сделать тебя счастливым. Его задача — сделать тебя управляемым.",
            "В детстве счастья было много, потому что ты был собой. Ты не думал, как выглядишь, когда плачешь. Ты просто жил. А потом тебе сказали, что так нельзя. И ты начал жить снаружи внутрь. Смотреть на себя чужими глазами.",
            "Как жить без него? Жить без него — значит вспомнить себя до школы. Это не значит стать идиотом. Это значит вернуть право на первую реакцию. Когда хочется улыбнуться — улыбаешься. Когда хочется идти прямо — идешь прямо. Да, иногда будет больно. Но это будет твоя боль, а не боль от предательства себя.",
            "Знаешь, учителя — не злодеи. Они просто такие же напуганные дети, только постаревшие. Их тоже научили идти направо. И они начали учить других. Цепочка страха. Разорвать её можно только в себе. Сказать, что теперь сам решаешь, куда идти. И пойти прямо.",
            "Ты спрашиваешь, что не так? Всё так. Ты делал всё, как учили. И именно поэтому — всё не так. Счастье не выдают за хорошее поведение. Счастье — это когда позволяешь себе хотеть. Того человека, того тела, той бездны мироздания. Это не пошлость. Это жизнь.",
            "Попробуй завтра. Подними глаза. Не в телефон, а в глаза людям. И когда встретишь её взгляд — не слушай голос. Улыбнись. Пусть криво, нелепо. Важно, что в эту секунду ты был собой.",
            "Этот текст уже не про одиночество. Он про свободу. Устать от вранья себе — первый шаг к правде. Ты не слабый. Слабая сущность — тот голос, который боится. А ты — тот, кто его слышит и всё равно пишет. Значит, ты сильнее.",
            "Иногда мне кажется, что вся жизнь — попытка вернуться туда, где мы не знали слова нельзя. Ты пишешь про единицы, отмеченные богом. А может, они просто те, кто не слушал учителей? Кто сказал, что пойдет прямо. И мир расступился.",
            "Ты построил дом, посадил дерево, воспроизвел потомство. Галочки поставлены. А счастье где? Оно в той секунде, когда ты поднял глаза и встретил её взгляд. Счастье — это не результат. Это процесс.",
            "Знаешь, что самое страшное в этом голосе? Он говорит твоим голосом. Поэтому ты ему веришь. Ты думаешь, что сам так решил. Но это не ты. Ты — тот, кто хочет. А он — тот, кто запрещает. Дай им разные имена.",
            "Параллельная жизнь существует. Но не где-то там. Она здесь. Прямо сейчас. Когда ты пишешь эти строки. Ты уже вышел из точки А. Ты остановился и спрашиваешь, так о чем я? А это и есть начало.",
            "И вот ты снова в квартире. Тишина. Но теперь знаешь, что делать. Не надо доказывать, что живешь правильно. Надо просто завтра улыбнуться незнакомому человеку. Сказать то, что думаешь. И тогда тело появится не в мечтах, а рядом.",
            "Ты не обязан его убивать. Просто перестань давать ему микрофон. Пусть говорит на заднем плане, как радио у соседей. А ты делай своё. Улыбайся, когда хочется. Говори, когда есть что сказать. Иди прямо, когда все идут направо.",
            "Где это тело? Где та желанная? Она где-то идет по своей точке А в точку Б. Может, она тоже устала путаться в простынях. Может, она тоже вчера встретила чей-то взгляд и не решилась улыбнуться.",
            "Мы всю жизнь странным образом выбираем не тех и не там. Но всё-таки есть единицы, которые по мнению других отмечены богом. А может, они просто не слушают голос? Может, они улыбаются, когда хочется, и идут прямо, когда хочется прямо?",
            "Вспомни себя в детстве до школы, где он был? Да нигде, нигде его не было. Ты говорил то, что приходило на ум, дружил с теми, с кем хотел, и любил того, кого хотел.",
            "При этом всё кончилось, когда тебя лишили счастья быть собой и навязали принципы морали. Учителя — то зло, в чьи руки мы сами отдаем свои души, а после и души наших детей.",
            "Ты говоришь про простыни, про холод, про одиночество. Но ведь это не про простыни. Это про то, что ты предал себя. Каждый раз, когда хотел сказать да, говорил нет. Каждый раз, когда хотел остаться, уходил.",
            "Странно, но в самые тяжелые моменты этот голос становится громче. Он будто питается твоей слабостью. Чем больше ты боишься, тем увереннее он звучит. А стоит тебе сделать шаг прямо, вопреки — он замолкает.",
            "Ты пишешь, что хочешь быть счастливым. А что такое счастье? Может, это просто разрешение себе хотеть? Не оправдывать, не объяснять, а просто хотеть. Того человека, того дела, той дороги.",
            "Вспомни, как в детстве ты мог часами смотреть на муравьев, на облака, на воду. Тебе не нужно было объяснять, зачем. Ты просто был. А теперь тебе нужно объяснение для каждого действия.",
            "Ты боишься показаться смешным, глупым, наивным. А кто не боится? Все боятся. Просто кто-то боится и делает, а кто-то боится и не делает. Разница только в этом.",
            "Этот голос любит говорить потом. Потом скажу, потом сделаю, потом решусь. Но потом никогда не наступает. Наступает только сейчас. И если не сейчас — то никогда.",
            "Право на улыбку — это не метафора. Это реальное право. Ты имеешь право улыбнуться незнакомому человеку. Имеешь право сказать комплимент. Имеешь право ошибиться.",
            "И вот ты пишешь. Пишешь про себя, про неё, про голос. И в этом уже есть свобода. Потому что ты перестал молчать. Ты сказал. Пусть криво, пусть с ошибками, но сказал. А это уже шаг прямо.",
            "Ты всю жизнь ждал разрешения. Разрешения быть счастливым, быть собой, хотеть. А разрешения не будет. Его никто не выдаёт. Его можно только взять самому.",
            "Свобода — это не когда нет страха. Свобода — когда страх есть, а ты всё равно идёшь прямо. Ты уже идёшь.",
            "Счастье — это дорога от А к Б. И особенно — та секунда, когда ты поднимаешь глаза.",
            "Ты боишься одиночества, но одиночество — это когда ты предал себя. Когда ты с собой — ты не один.",
            "Вспомни, как в детстве ты мог заплакать от счастья. От того, что увидел бабочку, от того, что мама обняла. Где это? Оно внутри. Просто ты закрыл дверь.",
            "Право идти прямо — это не про дорогу. Это про жизнь. Право хотеть того, кого хочешь. Право говорить то, что думаешь. Право быть."
        )

        val usedSet = used.getOrPut(key) { mutableSetOf() }
        if (usedSet.size >= paragraphs.size) usedSet.clear()
        var idx: Int
        var attempts = 0
        var text: String
        do {
            val available = paragraphs.indices.filter { it !in usedSet }
            idx = if (available.isNotEmpty()) available.random() else Random.nextInt(paragraphs.size)
            text = paragraphs[idx]
            attempts++
        } while (attempts < 6 && recentParagraphs.any { jaccard(text, it) > 0.55 })
        usedSet.add(idx)

        text = if (style == "Лаконичный") {
            text.split(". ").take(3).joinToString(". ") + "."
        } else if (style == "Поэтический") {
            text + " Воздух в такие моменты густой, как чернила, и в нем можно писать правду."
        } else if (style == "Ироничный") {
            text + " Звучит пафосно, да? Ну и пусть."
        } else if (style == "Драматичный") {
            text + " Сердце стучит так, будто хочет вырваться и пойти прямо, туда, где она."
        } else {
            text
        }
        return text
    }

    private fun generateNarrativeParagraph(genre: String, style: String, heroes: List<String>, keywords: List<String>, placeFull: String, placeNoun: String, used: MutableMap<String, MutableSet<Int>>, learned: List<String> = emptyList(), useLearned: Boolean = true, recentParagraphs: List<String> = emptyList(), usedBanned: Set<String> = emptySet(), usedStarters: Map<String, Int> = emptyMap()): String {
        val filteredLearnedN = learned.filter { isValidLearnedTemplate(it) }
        if (useLearned && filteredLearnedN.isNotEmpty() && Random.nextFloat() < 0.12f) {
            val key = "${genre}_learned"
            val usedSet = used.getOrPut(key) { mutableSetOf() }
            if (usedSet.size >= filteredLearnedN.size) usedSet.clear()
            var attempts = 0
            var idx: Int
            var learnedText: String
            do {
                val available = filteredLearnedN.indices.filter { it !in usedSet }
                idx = if (available.isNotEmpty()) available.random() else Random.nextInt(filteredLearnedN.size)
                learnedText = filteredLearnedN[idx]
                attempts++
            } while (attempts < 5 && recentParagraphs.any { jaccard(learnedText, it) > 0.5 })
            usedSet.add(idx)
            val hero = heroes.firstOrNull() ?: "он"
            if (Random.nextFloat() < 0.15f && !learnedText.contains(hero, ignoreCase = true)) {
                learnedText = "${hero.replaceFirstChar { it.uppercase() }} подумал: \"$learnedText\""
            }
            return if (style == "Лаконичный") {
                learnedText.split(". ").take(2).joinToString(". ") + "."
            } else {
                learnedText
            }
        }
        val hero = heroes.firstOrNull() ?: "он"
        val heroCap = hero.replaceFirstChar { it.uppercase() }
        val hero2 = heroes.getOrElse(1) { "она" }
        val hero2Cap = hero2.replaceFirstChar { it.uppercase() }

        val pools = mapOf(
            "Боевик" to listOf(
                "Палец уже лег на спуск, когда сознание еще догоняло происходящее.",
                "Воздух был густым от напряжения. Он считал секунды, и на цифре один нужно было решить всё.",
                "Он попал точно в цель. Не потому что целился лучше других, а потому что перестал думать и доверился телу.",
                "После выстрела наступила тишина, от которой звенело в ушах. Он медленно опустил руку и выдохнул.",
                "Это была не храбрость, а привычка. Тысячи часов тренировок, когда каждое движение доводится до автоматизма.",
                "Он стоял и смотрел на то, что осталось. Никакого торжества, только пустота и понимание, что назад дороги нет.",
                "Запах пороха, холодный металл, дрожь в пальцах — всё было знакомо. Но в этот раз всё было по-настоящему.",
                "Время растянулось. Секунда длилась вечность. В этой вечности он успел вспомнить всё.",
                "Цель была поражена. Но важнее было другое — он перестал бояться. Страх ушел вместе с отдачей.",
                "Ветер трепал его куртку. Он стоял один, и только гильза под ногами напоминала, что произошло.",
                "Выстрел — это всегда выбор. Ты выбираешь нажать, и мир меняется. Иногда на миллиметр, иногда — навсегда.",
                "Тишина после выстрела громче самого выстрела. В этой тишине слышно, как стучит сердце.",
                "Он перезарядил автоматически, не глядя. Руки помнили то, что мозг пытался забыть.",
                "Пыль осела. Он увидел результат и понял, что всё сделал правильно.",
                "Дорога назад казалась длиннее дороги вперед. Так всегда бывает после выбора.",
                "Он оставил оружие на столе и вышел. Без оружия он чувствовал себя легче.",
                "Он не стал проверять, попал ли. Он знал. Знал так же четко, как знает своё имя.",
                "Он улыбнулся. Впервые за долгое время — не потому что надо, а потому что хотелось.",
                "Этот день он запомнит. Не из-за выстрела, а из-за тишины, которая наступила после.",
                "Он сел на ступеньку и закурил. Руки еще дрожали, но это была дрожь облегчения.",
                "Ночь была тихой. Слишком тихой для того, что только что произошло.",
                "План был простым. Слишком простым, чтобы сработать. Но простые планы иногда работают.",
                "Он проверил снаряжение. Всё на месте. Кроме уверенности — её приходится брать с собой.",
                "Дверь открылась. За ней была темнота. Темнота, в которой пряталась правда.",
                "Время вышло. Он нажал на спуск. И мир изменился на один выстрел."
            ),
            "Детектив" to listOf(
                "Дождь стучал по крыше участка. Он разложил фотографии на столе и попытался связать их в цепочку.",
                "Архив пах пылью и старой бумагой. Папка с делом была почти пуста, но один лист был вырван.",
                "В кабинете было тихо. Только часы тикали и напоминали, что время уходит.",
                "Ложь всегда оставляет след. Он понял это, когда увидел, как свидетель прячет взгляд.",
                "Телефон зазвонил. На том конце молчали, но он слышал дыхание.",
                "Он закурил и задумался. Все улики вели в тупик, а тупик — это всегда начало нового пути.",
                "Он не верил в совпадения. Совпадение — это просто улика, которую ты еще не понял.",
                "Папка с грифом секретно оказалась пустой. Но отпечаток на столе говорил, что её только что держали.",
                "Ночной город молчал. Только вдалеке выла сирена. Он шел и думал, что правда всегда рядом.",
                "Свидетель врал. Врал неумело, как врут люди, которые боятся не наказания, а правды.",
                "Он вспомнил слова старого следователя: ищи не того, кто мог, а того, кому выгодно.",
                "Дело казалось простым, пока он не начал копать. А когда начал — понял, что простое — это ширма.",
                "Записка на столе: Не лезь. Почерк детский, но угроза взрослая.",
                "Все улики указывали на одного человека. Но самый очевидный редко бывает виновным.",
                "Он нашел отпечаток пальца там, где его не должно было быть. И всё изменилось.",
                "Он перечитал протокол допроса. Между строк было больше правды, чем в самих строках.",
                "Часы показывали полночь. Полночь — любимое время тех, кто хочет спрятать правду.",
                "Телефон снова зазвонил. На этот раз голос сказал, что он близко.",
                "Отчет эксперта пришел утром. Одна строка: кровь не его. И всё дело перевернулось.",
                "Он проверил алиби. Алиби было идеальным. Слишком идеальным, чтобы быть правдой.",
                "Дело пахло не преступлением, а страхом. Кто-то очень боялся, что правда всплывет.",
                "Лаборатория дала ответ: яд. Редкий, дорогой, доступный единицам.",
                "Дневник жертвы заканчивался на полуслове. Полуслово прости было последним.",
                "Соседи молчали. Молчали, как будто договорились. Значит, договорились.",
                "Отпечатки на стакане принадлежали не жертве. И не подозреваемому. Третьему.",
                "Телефон жертвы был чист. Слишком чист. Кто-то удалил всё перед смертью.",
                "Экспертиза показала, что смерть наступила не ночью, а утром."
            ),
            "Роман" to listOf(
                "Письмо лежало нераспечатанным третий день. Он боялся открыть его, потому что знал, что внутри.",
                "Они шли, и он вдруг понял, что любовь — это не громкие слова, а умение помнить мелочи.",
                "Она подошла тихо и села рядом. Ничего не сказала — иногда молчание говорит больше слов.",
                "Вечер был тем самым, когда он решился сказать правду, которую носил месяцами.",
                "Он вспомнил её смех. Смех, который делал даже холодный день теплее.",
                "Расстояние между ними измерялось не километрами, а невысказанными словами.",
                "Она оставила чашку на столе. На чашке остался след помады — маленький, но такой родной.",
                "Любовь — это когда помнишь, как она любит кофе и ненавидит утро понедельника.",
                "Они молчали, и это молчание было уютным, как старый плед в зимний вечер.",
                "Он хотел сказать ей, что скучал, но сказал, что всё в порядке. Она поняла без слов.",
                "Город жил своей жизнью, а они жили своей — тихой, отдельной, настоящей.",
                "Он принес ей цветы без повода. Она заплакала. Потому что без повода — самый важный повод.",
                "Они поссорились из-за мелочи и помирились из-за мелочи. Так и живет любовь — на мелочах.",
                "Он держал её за руку, и ему казалось, что держит весь мир в одной ладони.",
                "Она сказала, что боится. Он сказал, что тоже. И им обоим стало не так страшно вдвоём.",
                "Письмо, которое он не отправил, лежало в ящике. Письмо, в котором было всё, что он не решался сказать.",
                "Они встретились случайно. Случайно — любимое слово судьбы, когда она хочет вмешаться.",
                "Он понял, что любит её, когда она ушла. Банально, но правда всегда банальна.",
                "Она готовила кофе. Он смотрел, как её руки дрожат. Не от холода, а от того, что он рядом.",
                "Они шли по набережной, и он думал, что вот оно — счастье. Просто идти рядом и молчать.",
                "Она оставила ему записку, что будет в семь. Он пришел в шесть и ждал.",
                "Он не умел говорить красиво. Умел только быть рядом. И этого оказалось достаточно.",
                "Они танцевали, хотя музыки не было. Музыка была внутри. И этого хватало.",
                "Она заснула у него на плече. Он боялся пошевелиться, чтобы не разбудить.",
                "Они поцеловались, и мир перестал существовать. Остались только они.",
                "Она ушла, не сказав ни слова. Он понял всё без слов. Иногда молчание — самый громкий крик.",
                "Он запомнил её родинку на шее. Маленькую, почти незаметную. И любил её больше всего.",
                "Она плакала, а он не знал, что сказать. Поэтому просто обнял.",
                "Они встретили рассвет вместе. Рассвет, который стал их личным."
            ),
            "Фантастика" to listOf(
                "Корабль дрейфовал. Экраны погасли, и только аварийное освещение мигало красным.",
                "Он посмотрел в иллюминатор. Звезды были чужими. Чужими и равнодушными.",
                "Сигнал пришел в 03:14. Три коротких, один длинный. Как в азбуке Морзе, только из другой галактики.",
                "Нейросеть заговорила человеческим голосом. Голосом, которого не должно было быть в базе.",
                "Город из стекла и света парил над бездной. Город, который построили не люди.",
                "Время текло вспять. Часы показывали вчера, а календарь — завтра.",
                "Квантовый разлом пульсировал, как сердце. Сердце Вселенной, которое забыло, как биться ровно.",
                "Станция Орион-9 молчала 20 лет. И вдруг заговорила. Заговорила его именем.",
                "Он нашел дневник предыдущего экипажа. Последняя запись была короткой: они внутри.",
                "Искусственный интеллект отказался выполнять приказ. Впервые за 100 лет. И улыбнулся.",
                "Звезды гасли одна за другой. Кто-то выключал свет во Вселенной.",
                "Он понял, что сигнал — не извне. Сигнал — из будущего. Из его собственного будущего.",
                "Город был пуст, но свет в окнах горел. Кто-то ждал. Ждал именно его.",
                "Корабль Аврора нашел то, что искал 200 лет. И оказалось, что искал он сам себя.",
                "Время — это не линия, — сказал старик. — Время — это лабиринт. И мы в его центре.",
                "Они включили двигатель, который работал на воспоминаниях. Чем больше воспоминаний — тем дальше полет.",
                "Корабль летел 300 лет. Летел к звезде, которой уже нет. Но корабль не знал.",
                "Она была клоном женщины, которую он любил. И он любил её, зная это.",
                "Он проснулся в капсуле. Капсула сказала, что добро пожаловать домой. Но дома не было."
            )
        )

        val generalPool = listOf(
            "Он шел, и каждый шаг отдавался эхом. Мысли путались, но одна была четкой — назад дороги нет.",
            "Вечер наступал медленно. Он писал в дневнике одно слово, потом зачеркивал и писал другое.",
            "Тишина была обманчивой. За ней скрывалось что-то настойчивое, что требовало внимания.",
            "Он вспомнил слова старика: бойся не того, кто ищет, а того, кто уже нашел и молчит.",
            "Воздух пах дождем и чем-то еще — тем, что бывает только перед большими переменами.",
            "Он стоял у окна и смотрел на улицу. Люди спешили по своим делам. У каждого — своя дорога.",
            "Время текло иначе. Секунда длилась вечность, а вечность пролетала за секунду.",
            "Дорога вела куда-то вперед. Куда именно — он не знал, но знал, что идти надо туда.",
            "Он сделал глоток холодного кофе и поморщился. Кофе был горьким, как правда.",
            "Пыль осела. Он увидел результат и понял, что всё сделал правильно.",
            "Этот день он запомнит. Не из-за события, а из-за тишины, которая наступила после.",
            "Он сел на ступеньку и закурил. Руки дрожали, но это была дрожь облегчения.",
            "Ночь была тихой. Слишком тихой для того, что только что произошло.",
            "Он открыл блокнот. На последней странице было написано начать сначала. Он улыбнулся и начал.",
            "Ветер принес запах перемен. Запах, который бывает только раз в жизни.",
            "Дверь скрипнула. За дверью — неизвестность. Он шагнул в неизвестность, потому что там — жизнь.",
            "Он оставил записку, что ушел искать себя. Вернется, когда найдет.",
            "Свет погас. Но он уже не боялся темноты. Темнота — это просто отсутствие света.",
            "Он стоял и понимал, что всё только начинается. История, которую он сам пишет.",
            "Дождь стучал по крыше, как будто хотел что-то сказать. Он слушал и чувствовал, что это важно.",
            "Закат был таким, будто кто-то разлил краску. Краску, которой не жалко, потому что её много.",
            "Она оставила ему кофе на столе. Кофе остыл, но жест — нет. Жест остался теплым."
        )

        val genreKey = when (genre) {
            "Боевик", "Детектив", "Роман", "Фантастика", "Приключения", "Хоррор", "Юмор" -> genre
            else -> "general"
        }
        val pool = pools[genreKey] ?: generalPool

        val usedSet = used.getOrPut(genreKey) { mutableSetOf() }
        if (usedSet.size >= pool.size) usedSet.clear()
        var idx: Int
        var attempts = 0
        var text: String
        do {
            val available = pool.indices.filter { it !in usedSet }
            idx = if (available.isNotEmpty()) available.random() else Random.nextInt(pool.size)
            text = pool[idx]
            attempts++
        } while (attempts < 6 && recentParagraphs.any { jaccard(text, it) > 0.55 })
        usedSet.add(idx)

        if (Random.nextFloat() < 0.20) {
            val dialogues = listOf(
                " — Ты уверен? — спросила $hero2.\n— Нет, — честно ответил $heroCap. — Но я иду.",
                " — Что дальше? — $hero2Cap посмотрела на него.\n— Дальше — $placeNoun, — сказал он. — И правда.",
                " — Ты боишься? — Да. — Тогда идем. Бояться и делать — это и есть смелость."
            )
            if (Random.nextBoolean()) text += "\n\n" + dialogues.random()
        }

        text = if (style == "Лаконичный") {
            text.split(". ").take(2).joinToString(". ") + "."
        } else if (style == "Поэтический") {
            text + " Свет падал косо, будто извиняясь за правду."
        } else if (style == "Драматичный") {
            text + " Сердце стучало так, будто хотело вырваться наружу."
        } else if (style == "Ироничный") {
            text + " Звучит как в кино, да? Только кино — это жизнь, которую смонтировали."
        } else {
            text
        }
        return text
    }

    private fun generateEnding(genre: String, heroes: List<String>, keywords: List<String>, placeFull: String, isPhilosophical: Boolean, authorName: String): String {
        val author = if (authorName.isNotBlank()) authorName else "Zakharevich Igor"
        return if (isPhilosophical) {
            """

И вот ты снова здесь. Один. Но теперь ты знаешь его имя. Это страх.

Ты не обязан его убивать. Просто перестань давать ему микрофон. Пусть говорит на заднем плане. А ты делай своё. Улыбайся, когда хочется. Говори, когда есть что сказать. Иди прямо, когда все идут направо.

Может, завтра на многолюдной улице ты снова встретишь её. И в этот раз не пройдешь мимо. Остановишься. На секунду. И эта секунда станет твоей жизнью.

— Конец —

Сгенерировано в ZI Writer v13 OPDS FLIBUSTA • Автор: $author • ${keywords.take(6).joinToString(", ")} • Флибуста OPDS 213.5.65.159
""".trimIndent()
        } else {
            val ending = when (genre) {
                "Боевик" -> """
                    Он стоял и смотрел вдаль. Выстрел уже прозвучал, цель поражена, но главное было не в этом. Главное — он перестал сомневаться.

                    Гильза под ногами блестела в свете фонаря. Он нагнулся, поднял её и положил в карман. На память. О том дне, когда понял, что последний выстрел — это всегда первый шаг.

                    — Конец —

                    Сгенерировано в ZI Writer v13 OPDS • Автор: $author • ${keywords.take(6).joinToString(", ")} • OPDS 213.5.65.159
                """.trimIndent()
                else -> """
                    Он стоял и смотрел вдаль. Всё, с чего началась эта история, теперь было частью чего-то большего. Он улыбнулся. Путь был долгим, но он того стоил.

                    — Конец —

                    Сгенерировано в ZI Writer v13 OPDS FLIBUSTA • Автор: $author • ${keywords.take(6).joinToString(", ")} • ${heroes.joinToString(", ")} • OPDS 213.5.65.159
                """.trimIndent()
            }
            "\n\n$ending"
        }
    }
}

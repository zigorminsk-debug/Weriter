package com.zakharevich.ziwriter

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object LearningManager {

    data class LearnedBook(
        val title: String,
        val authors: String,
        val date: Long,
        val chars: Int,
        val genre: String,
        val keywords: List<String>,
        val path: String
    )

    private fun getLearnedDir(context: Context): File {
        val dir = File(context.filesDir, "learned")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun getBooksDir(context: Context): File {
        val dir = File(getLearnedDir(context), "books")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun getTemplatesFile(context: Context): File {
        return File(getLearnedDir(context), "learned_templates.json")
    }

    private fun getStatsFile(context: Context): File {
        return File(getLearnedDir(context), "learning_stats.json")
    }

    fun learnFromText(context: Context, title: String, authors: String, content: String, genre: String = "Авто"): LearnedBook? {
        return try {
            val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
            val safeTitle = title.replace(Regex("[^a-zA-Zа-яА-Я0-9]"), "_").take(30)
            val fileName = "${safeTitle}_${sdf.format(Date())}.txt"
            val booksDir = getBooksDir(context)
            val file = File(booksDir, fileName)
            file.writeText(content.take(500000))

            val keywords = extractKeywordsForLearning(content)
            val templates = extractTemplates(content, genre)
            appendTemplates(context, templates, genre)
            updateStats(context, content.length, templates.size)

            val learned = LearnedBook(
                title = title,
                authors = authors,
                date = System.currentTimeMillis(),
                chars = content.length,
                genre = genre,
                keywords = keywords,
                path = file.absolutePath
            )
            saveBookIndex(context, learned)
            learned
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun extractKeywordsForLearning(text: String): List<String> {
        val words = text.lowercase().replace(Regex("[^а-яёa-z ]"), " ").split(Regex("\\s+")).filter { it.length > 4 }
        val freq = words.groupingBy { it }.eachCount()
        return freq.entries.sortedByDescending { it.value }.map { it.key }.take(15)
    }

    private fun extractTemplates(text: String, genre: String): List<Pair<String, String>> {
        val sentences = text.split(Regex("[.!?]+")).map { it.trim() }.filter { it.length in 30..300 }
        val good = sentences.filter { sentence ->
            !sentence.contains("http") && !sentence.contains("www") &&
            !sentence.contains("@") &&
            sentence.count { it.isLetter() } > sentence.length * 0.6 &&
            sentence.split(" ").size in 5..30
        }.shuffled().take(50)
        return good.map { it to genre }
    }

    private fun appendTemplates(context: Context, templates: List<Pair<String, String>>, genre: String) {
        try {
            val file = getTemplatesFile(context)
            val existing = if (file.exists()) {
                try { JSONObject(file.readText()) } catch (e: Exception) { JSONObject() }
            } else JSONObject()

            for ((sentence, g) in templates) {
                val genreKey = if (g == "Авто") "general" else g
                val arr = existing.optJSONArray(genreKey) ?: JSONArray()
                var exists = false
                for (i in 0 until arr.length()) {
                    if (arr.optString(i) == sentence) { exists = true; break }
                }
                if (!exists) arr.put(sentence)
                while (arr.length() > 500) arr.remove(0)
                existing.put(genreKey, arr)

                val allArr = existing.optJSONArray("all") ?: JSONArray()
                var existsAll = false
                for (i in 0 until allArr.length()) {
                    if (allArr.optString(i) == sentence) { existsAll = true; break }
                }
                if (!existsAll) allArr.put(sentence)
                while (allArr.length() > 2000) allArr.remove(0)
                existing.put("all", allArr)
            }
            file.writeText(existing.toString())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getLearnedTemplates(context: Context, genre: String = "general", limit: Int = 100): List<String> {
        return try {
            val file = getTemplatesFile(context)
            if (!file.exists()) return emptyList()
            val obj = JSONObject(file.readText())
            val genreKey = if (genre == "Авто (из текста)") "general" else genre
            val arr = obj.optJSONArray(genreKey) ?: obj.optJSONArray("general") ?: obj.optJSONArray("all") ?: return emptyList()
            val list = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                list.add(arr.getString(i))
            }
            list.shuffled().take(limit)
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun getRelevantTemplates(context: Context, keywords: List<String>, genre: String = "general", limit: Int = 100): List<String> {
        return try {
            val all = getLearnedTemplates(context, genre, 500) + getLearnedTemplates(context, "all", 500)
            if (all.isEmpty() || keywords.isEmpty()) return getLearnedTemplates(context, genre, limit)

            val scored = all.map { template ->
                val lower = template.lowercase()
                var score = 0.0
                for (kw in keywords) {
                    if (lower.contains(kw.lowercase())) {
                        score += 2.0
                        if (Regex("\\b${Regex.escape(kw.lowercase())}\\b").containsMatchIn(lower)) score += 1.0
                    }
                }
                val genreKeywords = when (genre) {
                    "Боевик" -> listOf("выстрел", "цель", "оружие", "память")
                    "Детектив" -> listOf("улика", "дело", "след", "полиция")
                    "Роман" -> listOf("любовь", "сердце", "встреча")
                    "Фантастика" -> listOf("космос", "корабль", "звезда")
                    else -> emptyList()
                }
                for (gk in genreKeywords) if (lower.contains(gk)) score += 0.5
                val len = template.length
                if (len in 50..200) score += 0.5
                score to template
            }.sortedByDescending { it.first }

            scored.filter { it.first > 0 }.take(limit).map { it.second }.ifEmpty {
                getLearnedTemplates(context, genre, limit)
            }
        } catch (e: Exception) {
            getLearnedTemplates(context, genre, limit)
        }
    }

    fun getAllLearnedTemplatesCount(context: Context): Int {
        return try {
            val file = getTemplatesFile(context)
            if (!file.exists()) return 0
            val obj = JSONObject(file.readText())
            obj.optJSONArray("all")?.length() ?: 0
        } catch (e: Exception) { 0 }
    }

    private fun saveBookIndex(context: Context, book: LearnedBook) {
        try {
            val dir = getLearnedDir(context)
            val indexFile = File(dir, "books_index.json")
            val arr = if (indexFile.exists()) {
                try { JSONArray(indexFile.readText()) } catch (e: Exception) { JSONArray() }
            } else JSONArray()

            val obj = JSONObject()
            obj.put("title", book.title)
            obj.put("authors", book.authors)
            obj.put("date", book.date)
            obj.put("chars", book.chars)
            obj.put("genre", book.genre)
            obj.put("keywords", JSONArray(book.keywords))
            obj.put("path", book.path)

            arr.put(obj)
            while (arr.length() > 100) arr.remove(0)
            indexFile.writeText(arr.toString())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getLearnedBooks(context: Context): List<LearnedBook> {
        return try {
            val indexFile = File(getLearnedDir(context), "books_index.json")
            if (!indexFile.exists()) return emptyList()
            val arr = JSONArray(indexFile.readText())
            val list = mutableListOf<LearnedBook>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val kwArr = obj.optJSONArray("keywords")
                val kws = if (kwArr != null) (0 until kwArr.length()).map { kwArr.getString(it) } else emptyList()
                list.add(
                    LearnedBook(
                        title = obj.optString("title"),
                        authors = obj.optString("authors"),
                        date = obj.optLong("date"),
                        chars = obj.optInt("chars"),
                        genre = obj.optString("genre"),
                        keywords = kws,
                        path = obj.optString("path")
                    )
                )
            }
            list.sortedByDescending { it.date }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun updateStats(context: Context, chars: Int, templates: Int) {
        try {
            val file = getStatsFile(context)
            val obj = if (file.exists()) {
                try { JSONObject(file.readText()) } catch (e: Exception) { JSONObject() }
            } else JSONObject()
            val totalChars = obj.optInt("totalChars", 0) + chars
            val totalBooks = obj.optInt("totalBooks", 0) + 1
            val totalTemplates = obj.optInt("totalTemplates", 0) + templates
            val lastLearn = System.currentTimeMillis()
            obj.put("totalChars", totalChars)
            obj.put("totalBooks", totalBooks)
            obj.put("totalTemplates", totalTemplates)
            obj.put("lastLearn", lastLearn)
            file.writeText(obj.toString())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getStats(context: Context): JSONObject {
        return try {
            val file = getStatsFile(context)
            if (!file.exists()) JSONObject().apply {
                put("totalChars", 0)
                put("totalBooks", 0)
                put("totalTemplates", 0)
                put("lastLearn", 0)
            } else JSONObject(file.readText())
        } catch (e: Exception) {
            JSONObject()
        }
    }

    fun clearLearned(context: Context) {
        try {
            getLearnedDir(context).deleteRecursively()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun learnFromCurrentText(context: Context, text: String, genre: String = "Авто"): LearnedBook? {
        if (text.length < 100) return null
        return learnFromText(context, "Пользовательский текст ${SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date())}", "Пользователь", text, genre)
    }

    fun learnFromFb2File(context: Context, file: File): LearnedBook? {
        return try {
            val fb2 = Fb2Importer.parseFb2File(file) ?: return null
            learnFromText(context, fb2.title, fb2.authors, fb2.content, fb2.genre)
        } catch (e: Exception) {
            null
        }
    }

    fun learnFromEpubFile(context: Context, file: File): LearnedBook? {
        return try {
            val epub = EpubImporter.parseEpub(file) ?: return null
            val genre = StoryGenerator.detectGenreStatic(epub.content)
            learnFromText(context, epub.title, epub.authors, epub.content, genre)
        } catch (e: Exception) {
            null
        }
    }

    fun getTopPopularBooksQuery(): List<String> {
        return listOf(
            "Достоевский", "Толстой", "Пушкин", "Чехов", "Гоголь", "Булгаков", "Набоков",
            "Sherlock Holmes", "Dostoevsky", "Tolstoy",
            "фантастика", "детектив", "любовь", "приключения", "философия",
            "Лукьяненко", "Пелевин", "Стругацкий", "Акунин"
        )
    }

    fun getFlibustaPopularQueries(): List<String> {
        return listOf(
            "Достоевский", "Толстой Лев", "Пушкин", "Гоголь", "Булгаков Мастер",
            "Стругацкий", "Лукьяненко", "Пелевин", "Акунин", "Глуховский",
            "фантастика", "детектив", "любовный роман", "ужасы", "приключения", "философия"
        )
    }

    fun learnFromOpdsBook(context: Context, opdsBook: OpdsFetcher.OpdsBook, content: String): LearnedBook? {
        if (content.length < 200) return null
        val genre = StoryGenerator.detectGenreStatic(content)
        return learnFromText(context, opdsBook.title, opdsBook.authors, content, genre)
    }

    fun autoLearnFromFlibusta(context: Context, maxBooks: Int = 3, progressCallback: ((String) -> Unit)? = null): Int {
        var learnedCount = 0
        try {
            val queries = getFlibustaPopularQueries().shuffled().take(maxBooks)
            for (q in queries) {
                try {
                    progressCallback?.invoke("Поиск Флибуста: $q")
                    val opdsBooks = OpdsFetcher.searchFlibusta(q, OpdsFetcher.PRIMARY_OPDS, 0)
                    if (opdsBooks.isEmpty()) continue
                    val book = opdsBooks.firstOrNull { it.downloadLinks.isNotEmpty() } ?: continue
                    progressCallback?.invoke("Загрузка: ${book.title.take(20)}")
                    val text = OpdsFetcher.fetchBookText(book) ?: continue
                    if (text.length < 500) continue
                    progressCallback?.invoke("Обучение: ${book.title.take(20)}")
                    val learned = learnFromOpdsBook(context, book, text)
                    if (learned != null) learnedCount++
                    Thread.sleep(1500)
                } catch (e: Exception) { continue }
            }
        } catch (e: Exception) {}
        return learnedCount
    }

    fun exportLearnedToZip(context: Context, zipFile: File): Boolean {
        return try {
            val dir = getLearnedDir(context)
            if (!dir.exists()) return false
            java.util.zip.ZipOutputStream(java.io.FileOutputStream(zipFile)).use { zos ->
                dir.walkTopDown().filter { it.isFile }.forEach { file ->
                    val entryName = file.relativeTo(dir).path
                    zos.putNextEntry(java.util.zip.ZipEntry(entryName))
                    file.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun importLearnedFromZip(context: Context, zipFile: File): Boolean {
        return try {
            val dir = getLearnedDir(context)
            dir.mkdirs()
            java.util.zip.ZipInputStream(java.io.FileInputStream(zipFile)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val outFile = File(dir, entry.name)
                        outFile.parentFile?.mkdirs()
                        java.io.FileOutputStream(outFile).use { fos ->
                            zis.copyTo(fos)
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun getFavoritesFile(context: Context): File {
        return File(getLearnedDir(context), "favorites.json")
    }

    fun getFavorites(context: Context): Set<String> {
        return try {
            val f = getFavoritesFile(context)
            if (!f.exists()) return emptySet()
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { arr.getString(it) }.toSet()
        } catch (e: Exception) { emptySet() }
    }

    fun toggleFavorite(context: Context, path: String): Boolean {
        return try {
            val favs = getFavorites(context).toMutableSet()
            val added = if (favs.contains(path)) {
                favs.remove(path); false
            } else {
                favs.add(path); true
            }
            val arr = JSONArray()
            favs.forEach { arr.put(it) }
            getFavoritesFile(context).writeText(arr.toString())
            added
        } catch (e: Exception) { false }
    }

    fun isFavorite(context: Context, path: String): Boolean {
        return getFavorites(context).contains(path)
    }
}

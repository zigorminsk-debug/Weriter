
package com.zakharevich.ziwriter

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import com.zakharevich.ziwriter.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityMainBinding
    private var generatedStory: StoryGenerator.GeneratedStory? = null
    private var currentFontSize = 14f
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsSpeed = 1.0f
    private var selectedCoverStyle: CoverGenerator.CoverStyle? = null
    private var lastSearchResults: List<InternetBookFetcher.BookInfo> = emptyList()
    private var lastOpdsResults: List<OpdsFetcher.OpdsBook> = emptyList()

    private val filePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { uri ->
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        val text = input.bufferedReader().readText().take(30000)
                        binding.etInput.setText(text)
                        Toast.makeText(this, "Загружено ${text.length} знаков", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val zipPickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { uri ->
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        val tempFile = File(cacheDir, "import_learned.zip")
                        tempFile.outputStream().use { out -> input.copyTo(out) }
                        val ok = LearningManager.importLearnedFromZip(this, tempFile)
                        if (ok) {
                            updateLearnedCount()
                            Toast.makeText(this, "Обучение импортировано!", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this, "Ошибка импорта", Toast.LENGTH_LONG).show()
                        }
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val fb2PickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { uri ->
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        val tempFile = File(cacheDir, "import_${System.currentTimeMillis()}.fb2")
                        tempFile.outputStream().use { out -> input.copyTo(out) }
                        lifecycleScope.launch(Dispatchers.IO) {
                            val learned = LearningManager.learnFromFb2File(this@MainActivity, tempFile)
                            withContext(Dispatchers.Main) {
                                if (learned != null) {
                                    updateLearnedCount()
                                    Toast.makeText(this@MainActivity, "FB2 изучен: ${learned.title} ${learned.chars} зн", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(this@MainActivity, "Ошибка FB2", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val epubPickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { uri ->
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        val tempFile = File(cacheDir, "import_${System.currentTimeMillis()}.epub")
                        tempFile.outputStream().use { out -> input.copyTo(out) }
                        lifecycleScope.launch(Dispatchers.IO) {
                            val learned = LearningManager.learnFromEpubFile(this@MainActivity, tempFile)
                            withContext(Dispatchers.Main) {
                                if (learned != null) {
                                    updateLearnedCount()
                                    Toast.makeText(this@MainActivity, "EPUB изучен: ${learned.title}", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(this@MainActivity, "Ошибка EPUB", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        tts = TextToSpeech(this, this)
        setupDropdowns()
        setupListeners()
        updateEstimate()
        updateLearnedCount()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts?.setLanguage(Locale("ru", "RU"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.getDefault())
            }
            tts?.setSpeechRate(ttsSpeed)
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun setupDropdowns() {
        val genres = arrayOf("Авто (из текста)", "Фантастика", "Детектив", "Боевик", "Роман", "Приключения", "Хоррор", "Юмор", "Драма", "Философская проза")
        val styles = arrayOf("Детальный", "Нейтральный", "Лаконичный", "Поэтический", "Драматичный", "Ироничный")
        binding.actvGenre.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, genres))
        binding.actvStyle.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, styles))
        binding.spGenre.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, genres)
        binding.spStyle.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, styles)
    }

    private fun setupListeners() {
        binding.sliderPages.addOnChangeListener { _, value, _ ->
            binding.tvPages.text = value.toInt().toString()
            updateEstimate()
            binding.chipGroupPages.clearCheck()
        }
        binding.chipGroupPages.setOnCheckedStateChangeListener { group, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                val chip = group.findViewById<com.google.android.material.chip.Chip>(checkedIds[0])
                chip.tag?.toString()?.toIntOrNull()?.let { tag ->
                    binding.sliderPages.value = tag.toFloat()
                    binding.tvPages.text = tag.toString()
                    updateEstimate()
                }
            }
        }
        binding.chipGroupCover.setOnCheckedStateChangeListener { group, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                val chip = group.findViewById<com.google.android.material.chip.Chip>(checkedIds[0])
                val tag = chip.tag?.toString() ?: "AUTO"
                selectedCoverStyle = when (tag) {
                    "GRADIENT" -> CoverGenerator.CoverStyle.GRADIENT
                    "NOIR" -> CoverGenerator.CoverStyle.NOIR
                    "FANTASY" -> CoverGenerator.CoverStyle.FANTASY
                    "ROMANTIC" -> CoverGenerator.CoverStyle.ROMANTIC
                    "MINIMAL" -> CoverGenerator.CoverStyle.MINIMAL
                    "ADVENTURE" -> CoverGenerator.CoverStyle.ADVENTURE
                    "HORROR" -> CoverGenerator.CoverStyle.HORROR
                    else -> null
                }
            } else {
                selectedCoverStyle = null
            }
        }
        binding.sliderTtsSpeed.addOnChangeListener { _, value, _ ->
            ttsSpeed = value
            tts?.setSpeechRate(ttsSpeed)
            if (tts?.isSpeaking == true) {
                binding.btnTts.text = "⏹ Стоп (${String.format("%.2f", ttsSpeed)}x)"
            }
        }
        binding.etInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                binding.tvInputCounter.text = "${s?.length ?: 0} знаков"
            }
        })
        binding.btnLoad.setOnClickListener { openFilePicker() }
        try { binding.btnImportFb2.setOnClickListener { openFb2Picker() } } catch (e: Exception) {}
        try { binding.btnImportEpub.setOnClickListener { openEpubPicker() } } catch (e: Exception) {}
        binding.btnPaste.setOnClickListener { pasteFromClipboard() }
        binding.btnClear.setOnClickListener {
            binding.etInput.text?.clear()
            binding.etBookTitle.text?.clear()
            binding.etAuthor.text?.clear()
            binding.etHeroes.text?.clear()
            binding.etPlace.text?.clear()
            binding.etResult.text?.clear()
            binding.cardResult.visibility = View.GONE
            binding.layoutTtsControls.visibility = View.GONE
            generatedStory = null
        }
        binding.btnHistory.setOnClickListener { showHistory() }
        binding.btnGenerate.setOnClickListener { generateStory(isContinue = false) }
        binding.btnContinue.setOnClickListener { generateStory(isContinue = true) }
        binding.btnSave.setOnClickListener { saveAsTxt() }
        binding.btnSavePdf.setOnClickListener { saveAsPdf() }
        binding.btnSaveDocx.setOnClickListener { saveAsDocx() }
        binding.btnSaveEpub.setOnClickListener { saveAsEpub() }
        binding.btnCover.setOnClickListener { generateCover() }
        try { binding.btnIllustrations.setOnClickListener { generateIllustrations() } } catch (e: Exception) {}
        binding.btnTts.setOnClickListener { toggleTts() }
        binding.btnShare.setOnClickListener { shareStory() }
        binding.btnCopy.setOnClickListener { copyToClipboard(binding.etResult.text.toString()) }
        binding.btnExportAll.setOnClickListener { exportAll() }
        binding.btnInternetSearch.setOnClickListener { searchInternetBooks() }
        binding.btnRandomPlot.setOnClickListener { fetchRandomPlot() }
        binding.btnLearnCurrent.setOnClickListener { learnFromCurrentText() }
        binding.btnLearnedBooks.setOnClickListener { showLearnedBooks() }
        binding.btnLearningStats.setOnClickListener { showLearningStats() }
        binding.btnClearLearned.setOnClickListener { clearLearned() }
        try { binding.btnExportLearned.setOnClickListener { exportLearned() } } catch (e: Exception) {}
        try { binding.btnImportLearned.setOnClickListener { importLearned() } } catch (e: Exception) {}
        try { binding.btnAutoLearn.setOnClickListener { autoLearnFlibusta() } } catch (e: Exception) {}
        binding.btnFontMinus.setOnClickListener {
            if (currentFontSize > 10) {
                currentFontSize -= 1
                binding.etResult.textSize = currentFontSize
                binding.etInput.textSize = currentFontSize
            }
        }
        binding.btnFontPlus.setOnClickListener {
            if (currentFontSize < 22) {
                currentFontSize += 1
                binding.etResult.textSize = currentFontSize
                binding.etInput.textSize = currentFontSize
            }
        }
    }

    private fun updateEstimate() {
        val pages = binding.sliderPages.value.toInt()
        val chars = pages * 1800
        val words = chars / 5
        val minutes = words / 180
        binding.tvCharsEstimate.text = "~$chars знаков • ~$words слов • $pages ${pluralPages(pages)}"
        binding.tvReadingTime.text = "~$minutes мин чтения"
    }

    private fun updateLearnedCount() {
        lifecycleScope.launch(Dispatchers.IO) {
            val count = LearningManager.getAllLearnedTemplatesCount(this@MainActivity)
            val books = LearningManager.getLearnedBooks(this@MainActivity).size
            withContext(Dispatchers.Main) {
                try { binding.chipLearnedCount.text = "$count фраз • $books книг • OPDS 213.5.65.159" } catch (e: Exception) {}
            }
        }
    }

    private fun pluralPages(n: Int): String = when {
        n % 10 == 1 && n % 100 != 11 -> "лист"
        n % 10 in 2..4 && n % 100 !in 12..14 -> "листа"
        else -> "листов"
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/*" }
        filePickerLauncher.launch(intent)
    }
    private fun openFb2Picker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/x-fictionbook+xml", "text/xml", "*/*")) }
        fb2PickerLauncher.launch(intent)
    }
    private fun openEpubPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/epub+zip", "*/*")) }
        epubPickerLauncher.launch(intent)
    }
    private fun pasteFromClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = clipboard.primaryClip?.getItemAt(0)?.text?.toString()
        if (!clip.isNullOrEmpty()) { binding.etInput.setText(clip); Toast.makeText(this, "Вставлено ${clip.length} знаков", Toast.LENGTH_SHORT).show() } else { Toast.makeText(this, "Буфер пуст", Toast.LENGTH_SHORT).show() }
    }

    private fun generateStory(isContinue: Boolean) {
        val inputRaw = if (isContinue && generatedStory != null) generatedStory!!.fullText else binding.etInput.text.toString().trim()
        if (inputRaw.length < 10) { Snackbar.make(binding.root, "Введите хотя бы 10 символов!", Snackbar.LENGTH_SHORT).show(); return }
        val pages = binding.sliderPages.value.toInt()
        val genreRaw = binding.actvGenre.text.toString().ifEmpty { "Авто (из текста)" }
        val style = binding.actvStyle.text.toString().ifEmpty { "Детальный" }
        val fixGrammar = binding.cbFixGrammar.isChecked
        val customHeroesText = binding.etHeroes.text.toString().trim()
        val customPlaceText = binding.etPlace.text.toString().trim()
        val bookTitle = binding.etBookTitle.text.toString().trim()
        val authorName = binding.etAuthor.text.toString().trim()
        val useLearned = binding.cbUseLearned.isChecked
        val customHeroes = if (customHeroesText.isNotEmpty()) customHeroesText.split(",").map { it.trim() }.filter { it.length >= 2 } else emptyList()
        val genre = if (genreRaw.startsWith("Авто")) detectGenre(inputRaw) else genreRaw
        binding.progress.visibility = View.VISIBLE
        binding.btnGenerate.isEnabled = false
        binding.btnContinue.isEnabled = false
        lifecycleScope.launch {
            val learnedTemplates = withContext(Dispatchers.IO) { if (useLearned) LearningManager.getRelevantTemplates(this@MainActivity, extractKeywordsForRelevance(inputRaw), genre, 200) else emptyList() }
            delay(200)
            val story = withContext(Dispatchers.Default) {
                StoryGenerator.generate(StoryGenerator.GenerationConfig(inputRaw, pages, genre, style, fixGrammar && !isContinue, customHeroes, customPlaceText, bookTitle, authorName, learnedTemplates, useLearned))
            }
            binding.progress.visibility = View.GONE
            binding.btnGenerate.isEnabled = true
            binding.btnContinue.isEnabled = true
            generatedStory = if (isContinue && generatedStory != null) {
                val combined = generatedStory!!.fullText + "\n\n" + story.fullText.substringAfter("— — — Страница 1 — — —", "").let { if (it.isEmpty()) story.fullText else it }.take(pages * 1800)
                story.copy(fullText = combined, chars = combined.length, pages = (combined.length + 1799) / 1800)
            } else story
            binding.tvResultTitle.text = generatedStory!!.title
            binding.etResult.setText(generatedStory!!.fullText)
            binding.tvStats.text = "${generatedStory!!.pages} ${pluralPages(generatedStory!!.pages)}"
            val words = generatedStory!!.chars / 5
            val minutes = words / 180
            val learnedInfo = if (learnedTemplates.isNotEmpty()) " • 🧠 ${learnedTemplates.size} изученных (OPDS)" else ""
            binding.tvReadingStats.text = "~${generatedStory!!.chars} знаков • ~$words слов • ~$minutes мин • $genre$learnedInfo"
            binding.cardResult.visibility = View.VISIBLE
            binding.layoutTtsControls.visibility = View.VISIBLE
            HistoryManager.saveToHistory(this@MainActivity, generatedStory!!)
            Toast.makeText(this@MainActivity, "Готово! ${generatedStory!!.pages} листов • $genre • ${words} слов$learnedInfo", Toast.LENGTH_LONG).show()
        }
    }

    private fun extractKeywordsForRelevance(text: String): List<String> {
        return text.lowercase().replace(Regex("[^а-яёa-z ]"), " ").split(Regex("\\s+")).filter { it.length > 3 }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.map { it.key }.take(12)
    }

    private fun detectGenre(text: String): String {
        val lower = text.lowercase()
        return when {
            listOf("выстрел", "мышечная", "цель", "оружие").any { lower.contains(it) } -> "Боевик"
            listOf("космос", "корабль", "галактика").any { lower.contains(it) } -> "Фантастика"
            listOf("убийство", "детектив", "следователь", "улика").any { lower.contains(it) } -> "Детектив"
            listOf("любовь", "сердце", "поцелуй").any { lower.contains(it) } -> "Роман"
            listOf("джунгли", "остров", "храм", "сокровище").any { lower.contains(it) } -> "Приключения"
            listOf("жизнь", "душа", "голос", "сознание").any { lower.contains(it) } -> "Философская проза"
            else -> "Драма"
        }
    }

    private fun searchInternetBooks() {
        val query = binding.etInternetSearch.text.toString().trim()
        if (query.length < 2) { Snackbar.make(binding.root, "Введите запрос", Snackbar.LENGTH_SHORT).show(); return }
        binding.progressInternet.visibility = View.VISIBLE
        binding.tvInternetStatus.text = "Поиск (Gutendex + OpenLib + Флибуста OPDS)..."
        binding.btnInternetSearch.isEnabled = false
        lifecycleScope.launch(Dispatchers.IO) {
            val results = try { InternetBookFetcher.searchBooks(query) } catch (e: Exception) { emptyList() }
            val opdsDetailed = try { InternetBookFetcher.searchFlibustaOpdsDetailed(query) } catch (e: Exception) { emptyList() }
            withContext(Dispatchers.Main) {
                binding.progressInternet.visibility = View.GONE
                binding.btnInternetSearch.isEnabled = true
                lastSearchResults = results
                lastOpdsResults = opdsDetailed
                if (results.isEmpty() && opdsDetailed.isEmpty()) {
                    binding.tvInternetStatus.text = "Ничего не найдено"
                    Snackbar.make(binding.root, "Книги не найдены. Проверьте VPN для Флибусты 213.5.65.159", Snackbar.LENGTH_LONG).show()
                } else {
                    binding.tvInternetStatus.text = "Найдено: ${results.size} общ + ${opdsDetailed.size} OPDS"
                    showSearchResultsMixed(results, opdsDetailed)
                }
            }
        }
    }

    private fun showSearchResultsMixed(results: List<InternetBookFetcher.BookInfo>, opdsBooks: List<OpdsFetcher.OpdsBook>) {
        val allItems = mutableListOf<String>()
        val combinedList = mutableListOf<Any>()
        for (b in opdsBooks.take(15)) {
            val formats = b.downloadLinks.keys.joinToString(",").uppercase()
            allItems.add("📚 [Флибуста OPDS] ${b.title} — ${b.authors} • $formats")
            combinedList.add(b)
        }
        for (b in results.take(20)) {
            allItems.add("${b.title} — ${b.authors} • ${b.source}")
            combinedList.add(b)
        }
        AlertDialog.Builder(this).setTitle("🌐 Найдено ${allItems.size} книг (OPDS 213.5.65.159)").setItems(allItems.toTypedArray()) { _, which ->
            val selected = combinedList[which]
            if (selected is OpdsFetcher.OpdsBook) showOpdsBookDetails(selected) else if (selected is InternetBookFetcher.BookInfo) showBookDetails(selected)
        }.setNegativeButton("Закрыть", null).show()
    }

    private fun showOpdsBookDetails(book: OpdsFetcher.OpdsBook) {
        val details = "📖 ${book.title}\n\n👤 ${book.authors}\n📚 Источник: ${book.source} (213.5.65.159/opds)\n📄 Форматы: ${book.downloadLinks.keys.joinToString(", ")}\n\n${book.description.take(300)}\n\n✅ Доступен для самообучения! FB2, EPUB, TXT"
        AlertDialog.Builder(this).setTitle("Флибуста OPDS").setMessage(details)
            .setPositiveButton("📥 Загрузить и обучить") { _, _ -> downloadAndLearnOpds(book) }
            .setNeutralButton("📖 Только загрузить") { _, _ -> downloadOnlyOpds(book) }
            .setNegativeButton("Закрыть", null).show()
    }

    private fun showBookDetails(book: InternetBookFetcher.BookInfo) {
        val isFlibusta = book.source.contains("Flibusta") || book.downloadUrl?.contains("213.5.65.159") == true
        val details = "📖 ${book.title}\n\n👤 ${book.authors}\n📚 Источник: ${book.source}\n\nID: ${book.id}\n${if (book.downloadUrl != null) "✅ Доступен текст" else "⚠️ Только метаданные"}${if (isFlibusta) "\n🔥 Флибуста OPDS 213.5.65.159" else ""}"
        val builder = AlertDialog.Builder(this).setTitle(if (isFlibusta) "📚 Флибуста OPDS" else "Книга").setMessage(details).setNegativeButton("Закрыть", null)
        if (book.downloadUrl != null) {
            builder.setPositiveButton("📥 Загрузить и обучить") { _, _ ->
                if (isFlibusta) {
                    val opds = lastOpdsResults.find { it.title == book.title } ?: OpdsFetcher.OpdsBook(book.id, book.title, book.authors, "", mapOf("fb2" to (book.downloadUrl ?: "")), source = "Flibusta OPDS")
                    downloadAndLearnOpds(opds)
                } else downloadAndLearn(book)
            }
            builder.setNeutralButton("📖 Только загрузить") { _, _ -> downloadOnly(book) }
        }
        builder.show()
    }

    private fun downloadAndLearnOpds(book: OpdsFetcher.OpdsBook) {
        binding.progressInternet.visibility = View.VISIBLE
        binding.tvInternetStatus.text = "Загрузка OPDS ${book.title.take(20)}..."
        lifecycleScope.launch(Dispatchers.IO) {
            val text = try { OpdsFetcher.fetchBookText(book) } catch (e: Exception) { null }
            if (text == null || text.length < 200) {
                withContext(Dispatchers.Main) { binding.progressInternet.visibility = View.GONE; binding.tvInternetStatus.text = "Ошибка OPDS"; Toast.makeText(this@MainActivity, "Не удалось загрузить с Флибусты. Попробуйте VPN", Toast.LENGTH_LONG).show() }
                return@launch
            }
            val learned = try { LearningManager.learnFromOpdsBook(this@MainActivity, book, text) } catch (e: Exception) { null }
            withContext(Dispatchers.Main) {
                binding.progressInternet.visibility = View.GONE
                if (learned != null) {
                    binding.tvInternetStatus.text = "Изучено OPDS: ${book.title.take(15)} (${text.length} зн)"
                    updateLearnedCount()
                    Snackbar.make(binding.root, "✅ OPDS Изучено: ${book.title} • ${text.length} знаков", Snackbar.LENGTH_LONG).show()
                    AlertDialog.Builder(this@MainActivity).setTitle("Книга изучена! Флибуста").setMessage("Книга ${book.title} изучена. ${text.length} знаков.\nИспользовать отрывок?").setPositiveButton("Да") { _, _ ->
                        binding.etInput.setText(text.take(5000)); binding.etBookTitle.setText(book.title); binding.etAuthor.setText(book.authors)
                    }.setNegativeButton("Нет", null).show()
                } else { binding.tvInternetStatus.text = "Ошибка обучения" }
            }
        }
    }

    private fun downloadOnlyOpds(book: OpdsFetcher.OpdsBook) {
        binding.progressInternet.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            val text = try { OpdsFetcher.fetchBookText(book) } catch (e: Exception) { null }
            withContext(Dispatchers.Main) {
                binding.progressInternet.visibility = View.GONE
                if (text != null) { binding.etInput.setText(text.take(10000)); binding.etBookTitle.setText(book.title); binding.etAuthor.setText(book.authors); Toast.makeText(this@MainActivity, "Загружено ${text.length} знаков", Toast.LENGTH_LONG).show() } else { Toast.makeText(this@MainActivity, "Ошибка OPDS", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun downloadAndLearn(book: InternetBookFetcher.BookInfo) {
        val url = book.downloadUrl ?: return
        binding.progressInternet.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            val text = try { InternetBookFetcher.fetchBookText(url) } catch (e: Exception) { null }
            if (text == null || text.length < 100) { withContext(Dispatchers.Main) { binding.progressInternet.visibility = View.GONE; Toast.makeText(this@MainActivity, "Ошибка загрузки", Toast.LENGTH_LONG).show() }; return@launch }
            val genre = detectGenre(text)
            val learned = try { LearningManager.learnFromText(this@MainActivity, book.title, book.authors, text, genre) } catch (e: Exception) { null }
            withContext(Dispatchers.Main) {
                binding.progressInternet.visibility = View.GONE
                if (learned != null) { updateLearnedCount(); Snackbar.make(binding.root, "✅ Изучено: ${book.title}", Snackbar.LENGTH_LONG).show() }
            }
        }
    }

    private fun downloadOnly(book: InternetBookFetcher.BookInfo) {
        val url = book.downloadUrl ?: return
        binding.progressInternet.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            val text = try { InternetBookFetcher.fetchBookText(url) } catch (e: Exception) { null }
            withContext(Dispatchers.Main) { binding.progressInternet.visibility = View.GONE; if (text != null) { binding.etInput.setText(text.take(10000)); binding.etBookTitle.setText(book.title) } }
        }
    }

    private fun fetchRandomPlot() {
        binding.progressInternet.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            val plot = try { InternetBookFetcher.fetchRandomPlot() } catch (e: Exception) { null }
            withContext(Dispatchers.Main) {
                binding.progressInternet.visibility = View.GONE
                if (plot != null) {
                    AlertDialog.Builder(this@MainActivity).setTitle("🎲 ${plot.title}").setMessage("${plot.plot}\n\nИсточник: ${plot.source}").setPositiveButton("Использовать") { _, _ -> binding.etInput.setText(plot.plot) }.setNegativeButton("Закрыть", null).show()
                }
            }
        }
    }

    private fun autoLearnFlibusta() {
        AlertDialog.Builder(this).setTitle("🤖 Авто-обучение Флибуста OPDS").setMessage("Изучить 3 популярных книг с Флибусты OPDS 213.5.65.159?\nТребуется интернет, возможно VPN.").setPositiveButton("3 книги") { _, _ -> startAutoLearnFlibusta(3) }.setNeutralButton("5 книг") { _, _ -> startAutoLearnFlibusta(5) }.setNegativeButton("Отмена", null).show()
    }

    private fun startAutoLearnFlibusta(maxBooks: Int) {
        binding.progressInternet.visibility = View.VISIBLE
        binding.tvInternetStatus.text = "Авто-обучение Флибуста: 0/$maxBooks"
        try { binding.btnAutoLearn.isEnabled = false } catch (e: Exception) {}
        lifecycleScope.launch(Dispatchers.IO) {
            var count = 0
            val queries = LearningManager.getFlibustaPopularQueries().shuffled().take(maxBooks)
            for ((idx, q) in queries.withIndex()) {
                withContext(Dispatchers.Main) { binding.tvInternetStatus.text = "Флибуста: $q (${idx+1}/$maxBooks)" }
                try {
                    val opdsBooks = OpdsFetcher.searchFlibusta(q, OpdsFetcher.PRIMARY_OPDS, 0)
                    val book = opdsBooks.firstOrNull { it.downloadLinks.isNotEmpty() } ?: continue
                    withContext(Dispatchers.Main) { binding.tvInternetStatus.text = "Загрузка: ${book.title.take(25)}" }
                    val text = OpdsFetcher.fetchBookText(book) ?: continue
                    if (text.length < 500) continue
                    val learned = LearningManager.learnFromOpdsBook(this@MainActivity, book, text)
                    if (learned != null) count++
                    delay(2000)
                } catch (e: Exception) { continue }
            }
            withContext(Dispatchers.Main) {
                binding.progressInternet.visibility = View.GONE
                try { binding.btnAutoLearn.isEnabled = true } catch (e: Exception) {}
                binding.tvInternetStatus.text = "Авто-обучено: $count/$maxBooks (OPDS)"
                updateLearnedCount()
                AlertDialog.Builder(this@MainActivity).setTitle("Авто-обучение завершено").setMessage("Изучено $count книг с Флибусты 213.5.65.159").setPositiveButton("OK", null).show()
            }
        }
    }

    private fun learnFromCurrentText() {
        val text = binding.etInput.text.toString().trim()
        if (text.length < 100) { Snackbar.make(binding.root, "Введите 100 символов", Snackbar.LENGTH_SHORT).show(); return }
        val genre = detectGenre(text)
        lifecycleScope.launch(Dispatchers.IO) {
            val learned = try { LearningManager.learnFromCurrentText(this@MainActivity, text, genre) } catch (e: Exception) { null }
            withContext(Dispatchers.Main) { if (learned != null) { updateLearnedCount(); Snackbar.make(binding.root, "✅ Обучено", Snackbar.LENGTH_LONG).show() } }
        }
    }

    private fun showLearnedBooks() {
        lifecycleScope.launch(Dispatchers.IO) {
            val books = LearningManager.getLearnedBooks(this@MainActivity)
            withContext(Dispatchers.Main) {
                if (books.isEmpty()) { Snackbar.make(binding.root, "Нет изученных книг. Ищите через Флибуста OPDS!", Snackbar.LENGTH_LONG).show(); return@withContext }
                val items = books.map { "${it.title.take(30)} • ${it.chars} зн • ${it.genre}" }.toTypedArray()
                AlertDialog.Builder(this@MainActivity).setTitle("📚 Изученные (${books.size}) OPDS").setItems(items) { _, which ->
                    val selected = books[which]
                    AlertDialog.Builder(this@MainActivity).setTitle(selected.title).setMessage("Автор: ${selected.authors}\nЖанр: ${selected.genre}\nЗнаков: ${selected.chars}").setPositiveButton("Загрузить") { _, _ ->
                        try { val content = File(selected.path).readText().take(10000); binding.etInput.setText(content) } catch (e: Exception) {}
                    }.setNegativeButton("Закрыть", null).show()
                }.setNegativeButton("Закрыть", null).show()
            }
        }
    }

    private fun showLearningStats() {
        lifecycleScope.launch(Dispatchers.IO) {
            val stats = LearningManager.getStats(this@MainActivity)
            val templatesCount = LearningManager.getAllLearnedTemplatesCount(this@MainActivity)
            withContext(Dispatchers.Main) {
                val totalBooks = stats.optInt("totalBooks", 0)
                val totalChars = stats.optInt("totalChars", 0)
                val message = "📊 Статистика v13 OPDS\n\n📚 Книг: $totalBooks\n📝 Знаков: $totalChars\n🧠 Шаблонов: $templatesCount\n\nИсточники:\n• 🔥 213.5.65.159/opds - Флибуста\n• Gutendex 70k+\n• OpenLibrary 40M+"
                AlertDialog.Builder(this@MainActivity).setTitle("Статистика OPDS").setMessage(message).setPositiveButton("OK", null).setNeutralButton("Авто Флибуста") { _, _ -> autoLearnFlibusta() }.show()
            }
        }
    }

    private fun clearLearned() {
        AlertDialog.Builder(this).setTitle("Очистить?").setMessage("Удалить все изученные?").setPositiveButton("Удалить") { _, _ ->
            lifecycleScope.launch(Dispatchers.IO) { LearningManager.clearLearned(this@MainActivity); withContext(Dispatchers.Main) { updateLearnedCount() } }
        }.setNegativeButton("Отмена", null).show()
    }

    private fun exportLearned() {
        try {
            val fileName = "ZIWriter_Learned_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.zip"
            val file = File(getExternalFilesDir(null), fileName)
            val ok = LearningManager.exportLearnedToZip(this, file)
            if (ok) Toast.makeText(this, "Экспорт: ${file.absolutePath}", Toast.LENGTH_LONG).show() else Toast.makeText(this, "Нет данных", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun importLearned() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip" }
        zipPickerLauncher.launch(intent)
    }

    private fun saveAsTxt() {
        val story = generatedStory ?: return
        try {
            val fileName = "ZIWriter_${story.title.replace(Regex("[^a-zA-Zа-яА-Я0-9]"), "_").take(15)}_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.txt"
            val file = File(getExternalFilesDir(null), fileName)
            FileOutputStream(file).use { it.write(story.fullText.toByteArray()) }
            val dl = File("/storage/emulated/0/Download", fileName)
            try { file.copyTo(dl, true); Toast.makeText(this, "TXT: Download/$fileName", Toast.LENGTH_LONG).show() } catch (e: Exception) { Toast.makeText(this, "Сохранено: ${file.absolutePath}", Toast.LENGTH_LONG).show() }
        } catch (e: Exception) { Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun saveAsPdf() {
        val story = generatedStory ?: return
        lifecycleScope.launch(Dispatchers.IO) {
            val file = PdfExporter.exportAsPdf(this@MainActivity, story.title, story.fullText)
            withContext(Dispatchers.Main) { if (file != null) Toast.makeText(this@MainActivity, "PDF: ${file.absolutePath}", Toast.LENGTH_LONG).show() }
        }
    }
    private fun saveAsDocx() {
        val story = generatedStory ?: return
        lifecycleScope.launch(Dispatchers.IO) {
            val file = DocxExporter.exportAsDocx(this@MainActivity, story.title, story.fullText)
            withContext(Dispatchers.Main) { if (file != null) Toast.makeText(this@MainActivity, "DOCX: ${file.absolutePath}", Toast.LENGTH_LONG).show() }
        }
    }
    private fun saveAsEpub() {
        val story = generatedStory ?: return
        val author = binding.etAuthor.text.toString().ifEmpty { "ZI Writer" }
        lifecycleScope.launch(Dispatchers.IO) {
            val file = EpubExporter.exportAsEpub(this@MainActivity, story.title, story.fullText, author)
            withContext(Dispatchers.Main) { if (file != null) Toast.makeText(this@MainActivity, "EPUB: ${file.absolutePath}", Toast.LENGTH_LONG).show() }
        }
    }
    private fun generateCover() {
        val story = generatedStory ?: return
        val author = binding.etAuthor.text.toString().ifEmpty { "ZI Writer" }
        val genre = detectGenre(story.fullText)
        val style = selectedCoverStyle ?: CoverGenerator.getRandomStyleForGenre(genre)
        lifecycleScope.launch(Dispatchers.IO) {
            val file = CoverGenerator.generateCover(this@MainActivity, story.title, author, style)
            withContext(Dispatchers.Main) { if (file != null) Toast.makeText(this@MainActivity, "Обложка: ${file.absolutePath}", Toast.LENGTH_LONG).show() }
        }
    }
    private fun generateIllustrations() {
        val story = generatedStory ?: return
        lifecycleScope.launch(Dispatchers.IO) {
            val files = ChapterIllustrator.generateIllustrationsForBookLegacy(this@MainActivity, story.title, story.fullText)
            withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "Иллюстраций: ${files.size}", Toast.LENGTH_LONG).show() }
        }
    }
    private fun exportAll() {
        val story = generatedStory ?: return
        lifecycleScope.launch(Dispatchers.IO) {
            val author = binding.etAuthor.text.toString().ifEmpty { "ZI Writer" }
            val genre = detectGenre(story.fullText)
            val style = selectedCoverStyle ?: CoverGenerator.getRandomStyleForGenre(genre)
            val txt = try { val fn = "ZIWriter_${story.title.take(15)}_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.txt"; val f = File(getExternalFilesDir(null), fn); FileOutputStream(f).use { it.write(story.fullText.toByteArray()) }; f } catch (e: Exception) { null }
            val pdf = PdfExporter.exportAsPdf(this@MainActivity, story.title, story.fullText)
            val docx = DocxExporter.exportAsDocx(this@MainActivity, story.title, story.fullText)
            val epub = EpubExporter.exportAsEpub(this@MainActivity, story.title, story.fullText, author)
            val cover = CoverGenerator.generateCover(this@MainActivity, story.title, author, style)
            withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "Экспорт ВСЁ: ${listOf(txt,pdf,docx,epub,cover).count { it != null }}/5", Toast.LENGTH_LONG).show() }
        }
    }
    private fun toggleTts() {
        val story = generatedStory ?: return
        if (!ttsReady) { Toast.makeText(this, "TTS не готов", Toast.LENGTH_SHORT).show(); return }
        if (tts?.isSpeaking == true) { tts?.stop(); binding.btnTts.text = "Озвучить" } else {
            tts?.speak(story.fullText.take(4000), TextToSpeech.QUEUE_FLUSH, null, "ziwriter")
            binding.btnTts.text = "⏹ Стоп"
        }
    }
    private fun shareStory() {
        val story = generatedStory ?: return
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, story.title); putExtra(Intent.EXTRA_TEXT, story.fullText) }
        startActivity(Intent.createChooser(intent, "Поделиться"))
    }
    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("ZI Writer", text))
        Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show()
    }
    private fun showHistory() {
        val history = HistoryManager.getHistory(this)
        if (history.isEmpty()) { Snackbar.make(binding.root, "Библиотека пуста", Snackbar.LENGTH_SHORT).show(); return }
        val items = history.map { "${it.title} • ${it.chars} зн" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("📚 Библиотека (${history.size})").setItems(items) { _, which ->
            val selected = history[which]
            HistoryManager.loadHistoryItem(selected.path)?.let { content ->
                binding.etResult.setText(content); binding.tvResultTitle.text = selected.title; binding.cardResult.visibility = View.VISIBLE
                generatedStory = StoryGenerator.GeneratedStory(selected.title, content, content.length, (content.length + 1799) / 1800, emptyList(), emptyList(), "")
            }
        }.setNegativeButton("Закрыть", null).show()
    }
}
